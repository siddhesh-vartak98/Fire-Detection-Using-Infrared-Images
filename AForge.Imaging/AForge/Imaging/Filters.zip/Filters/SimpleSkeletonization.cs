﻿namespace AForge.Imaging.Filters
{
    using AForge;
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class SimpleSkeletonization : BaseUsingCopyPartialFilter
    {
        private byte bg;
        private byte fg;
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;

        public SimpleSkeletonization()
        {
            this.fg = 0xff;
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
        }

        public SimpleSkeletonization(byte bg, byte fg) : this()
        {
            this.bg = bg;
            this.fg = fg;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage source, UnmanagedImage destination, Rectangle rect)
        {
            int num8;
            int left = rect.Left;
            int top = rect.Top;
            int num3 = left + rect.Width;
            int num4 = top + rect.Height;
            int stride = source.Stride;
            int num6 = destination.Stride;
            int num7 = stride - rect.Width;
            byte* numPtr = (byte*) source.ImageData.ToPointer();
            byte* numPtr2 = (byte*) destination.ImageData.ToPointer();
            byte* numPtr3 = numPtr;
            byte* numPtr4 = numPtr2;
            numPtr3 += (top * stride) + left;
            numPtr4 += top * num6;
            for (int i = top; i < num4; i++)
            {
                SystemTools.SetUnmanagedMemory(numPtr4 + left, this.bg, num3 - left);
                num8 = -1;
                int num10 = left;
                while (num10 < num3)
                {
                    if (num8 == -1)
                    {
                        if (numPtr3[0] == this.fg)
                        {
                            num8 = num10;
                        }
                    }
                    else if (numPtr3[0] != this.fg)
                    {
                        numPtr4[num8 + ((num10 - num8) >> 1)] = this.fg;
                        num8 = -1;
                    }
                    num10++;
                    numPtr3++;
                }
                if (num8 != -1)
                {
                    numPtr4[num8 + ((num3 - num8) >> 1)] = this.fg;
                }
                numPtr3 += num7;
                numPtr4 += num6;
            }
            numPtr += top * stride;
            for (int j = left; j < num3; j++)
            {
                numPtr3 = numPtr + j;
                numPtr4 = numPtr2 + j;
                num8 = -1;
                int num12 = top;
                while (num12 < num4)
                {
                    if (num8 == -1)
                    {
                        if (numPtr3[0] == this.fg)
                        {
                            num8 = num12;
                        }
                    }
                    else if (numPtr3[0] != this.fg)
                    {
                        numPtr4[num6 * (num8 + ((num12 - num8) >> 1))] = this.fg;
                        num8 = -1;
                    }
                    num12++;
                    numPtr3 += stride;
                }
                if (num8 != -1)
                {
                    numPtr4[num6 * (num8 + ((num4 - num8) >> 1))] = this.fg;
                }
            }
        }

        public byte Background
        {
            get
            {
                return this.bg;
            }
            set
            {
                this.bg = value;
            }
        }

        public byte Foreground
        {
            get
            {
                return this.fg;
            }
            set
            {
                this.fg = value;
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }
    }
}

