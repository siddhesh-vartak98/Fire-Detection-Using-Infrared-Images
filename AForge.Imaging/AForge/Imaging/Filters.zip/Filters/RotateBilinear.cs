﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing.Imaging;

    public class RotateBilinear : BaseRotateFilter
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;

        public RotateBilinear(double angle) : this(angle, false)
        {
        }

        public RotateBilinear(double angle, bool keepSize) : base(angle, keepSize)
        {
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage sourceData, UnmanagedImage destinationData)
        {
            double num17;
            double num18;
            double num19;
            double num20;
            double num21;
            double num22;
            double num23;
            double num24;
            double num25;
            double num26;
            int num27;
            int num28;
            int num29;
            int num30;
            byte* numPtr3;
            byte* numPtr4;
            int width = sourceData.Width;
            int height = sourceData.Height;
            double num3 = ((double) width) / 2.0;
            double num4 = ((double) height) / 2.0;
            int num5 = destinationData.Width;
            int num6 = destinationData.Height;
            double num7 = ((double) num5) / 2.0;
            double num8 = ((double) num6) / 2.0;
            double d = (-base.angle * 3.1415926535897931) / 180.0;
            double num10 = Math.Cos(d);
            double num11 = Math.Sin(d);
            int stride = sourceData.Stride;
            int num13 = destinationData.Stride - ((destinationData.PixelFormat == PixelFormat.Format8bppIndexed) ? num5 : (num5 * 3));
            byte r = this.fillColor.R;
            byte g = this.fillColor.G;
            byte b = this.fillColor.B;
            byte* numPtr = (byte*) sourceData.ImageData.ToPointer();
            byte* numPtr2 = (byte*) destinationData.ImageData.ToPointer();
            int num31 = height - 1;
            int num32 = width - 1;
            if (destinationData.PixelFormat == PixelFormat.Format8bppIndexed)
            {
                num18 = -num8;
                for (int i = 0; i < num6; i++)
                {
                    num21 = (num11 * num18) + num3;
                    num22 = (num10 * num18) + num4;
                    num17 = -num7;
                    int num34 = 0;
                    while (num34 < num5)
                    {
                        num19 = num21 + (num10 * num17);
                        num20 = num22 - (num11 * num17);
                        num27 = (int) num19;
                        num28 = (int) num20;
                        if (((num27 < 0) || (num28 < 0)) || ((num27 >= width) || (num28 >= height)))
                        {
                            numPtr2[0] = g;
                        }
                        else
                        {
                            num29 = (num27 == num32) ? num27 : (num27 + 1);
                            num30 = (num28 == num31) ? num28 : (num28 + 1);
                            num23 = num19 - num27;
                            if (num23 < 0.0)
                            {
                                num23 = 0.0;
                            }
                            num25 = 1.0 - num23;
                            num24 = num20 - num28;
                            if (num24 < 0.0)
                            {
                                num24 = 0.0;
                            }
                            num26 = 1.0 - num24;
                            numPtr3 = numPtr + (num28 * stride);
                            numPtr4 = numPtr + (num30 * stride);
                            numPtr2[0] = (byte) ((num26 * ((num25 * numPtr3[num27]) + (num23 * numPtr3[num29]))) + (num24 * ((num25 * numPtr4[num27]) + (num23 * numPtr4[num29]))));
                        }
                        num17++;
                        num34++;
                        numPtr2++;
                    }
                    num18++;
                    numPtr2 += num13;
                }
            }
            else
            {
                num18 = -num8;
                for (int j = 0; j < num6; j++)
                {
                    num21 = (num11 * num18) + num3;
                    num22 = (num10 * num18) + num4;
                    num17 = -num7;
                    int num36 = 0;
                    while (num36 < num5)
                    {
                        num19 = num21 + (num10 * num17);
                        num20 = num22 - (num11 * num17);
                        num27 = (int) num19;
                        num28 = (int) num20;
                        if (((num27 < 0) || (num28 < 0)) || ((num27 >= width) || (num28 >= height)))
                        {
                            numPtr2[2] = r;
                            numPtr2[1] = g;
                            numPtr2[0] = b;
                        }
                        else
                        {
                            byte* numPtr6;
                            num29 = (num27 == num32) ? num27 : (num27 + 1);
                            num30 = (num28 == num31) ? num28 : (num28 + 1);
                            num23 = num19 - num27;
                            if (num23 < 0.0)
                            {
                                num23 = 0.0;
                            }
                            num25 = 1.0 - num23;
                            num24 = num20 - num28;
                            if (num24 < 0.0)
                            {
                                num24 = 0.0;
                            }
                            num26 = 1.0 - num24;
                            numPtr3 = numPtr4 = numPtr + (num28 * stride);
                            numPtr3 += num27 * 3;
                            numPtr4 += num29 * 3;
                            byte* numPtr5 = numPtr6 = numPtr + (num30 * stride);
                            numPtr5 += num27 * 3;
                            numPtr6 += num29 * 3;
                            numPtr2[2] = (byte) ((num26 * ((num25 * numPtr3[2]) + (num23 * numPtr4[2]))) + (num24 * ((num25 * numPtr5[2]) + (num23 * numPtr6[2]))));
                            numPtr2[1] = (byte) ((num26 * ((num25 * numPtr3[1]) + (num23 * numPtr4[1]))) + (num24 * ((num25 * numPtr5[1]) + (num23 * numPtr6[1]))));
                            numPtr2[0] = (byte) ((num26 * ((num25 * numPtr3[0]) + (num23 * numPtr4[0]))) + (num24 * ((num25 * numPtr5[0]) + (num23 * numPtr6[0]))));
                        }
                        num17++;
                        num36++;
                        numPtr2 += 3;
                    }
                    num18++;
                    numPtr2 += num13;
                }
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }
    }
}

