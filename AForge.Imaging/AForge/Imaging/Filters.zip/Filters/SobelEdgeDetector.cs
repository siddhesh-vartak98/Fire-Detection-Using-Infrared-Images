﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class SobelEdgeDetector : BaseUsingCopyPartialFilter
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
        private bool scaleIntensity = true;

        public SobelEdgeDetector()
        {
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage source, UnmanagedImage destination, Rectangle rect)
        {
            int num = rect.Left + 1;
            int num2 = rect.Top + 1;
            int num3 = (num + rect.Width) - 2;
            int num4 = (num2 + rect.Height) - 2;
            int stride = destination.Stride;
            int index = source.Stride;
            int num7 = (stride - rect.Width) + 2;
            int num8 = (index - rect.Width) + 2;
            byte* numPtr = (byte*) source.ImageData.ToPointer();
            byte* numPtr2 = (byte*) destination.ImageData.ToPointer();
            numPtr += (index * num2) + num;
            numPtr2 += (stride * num2) + num;
            double num10 = 0.0;
            for (int i = num2; i < num4; i++)
            {
                int num12 = num;
                while (num12 < num3)
                {
                    double num9 = Math.Min(0xff, Math.Abs((int) ((((numPtr[-index - 1] + numPtr[-index + 1]) - numPtr[index - 1]) - numPtr[index + 1]) + (2 * (numPtr[-index] - numPtr[index])))) + Math.Abs((int) ((((numPtr[-index + 1] + numPtr[index + 1]) - numPtr[-index - 1]) - numPtr[index - 1]) + (2 * (numPtr[1] - numPtr[-1])))));
                    if (num9 > num10)
                    {
                        num10 = num9;
                    }
                    numPtr2[0] = (byte) num9;
                    num12++;
                    numPtr++;
                    numPtr2++;
                }
                numPtr += num8;
                numPtr2 += num7;
            }
            if (this.scaleIntensity && (num10 != 255.0))
            {
                double num13 = 255.0 / num10;
                numPtr2 = (byte*) (destination.ImageData.ToPointer() + stride);
                for (int j = num2; j < num4; j++)
                {
                    numPtr2++;
                    int num15 = num;
                    while (num15 < num3)
                    {
                        numPtr2[0] = (byte) (num13 * numPtr2[0]);
                        num15++;
                        numPtr2++;
                    }
                    numPtr2 += num7;
                }
            }
            Drawing.Rectangle(destination, rect, Color.Black);
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public bool ScaleIntensity
        {
            get
            {
                return this.scaleIntensity;
            }
            set
            {
                this.scaleIntensity = value;
            }
        }
    }
}

