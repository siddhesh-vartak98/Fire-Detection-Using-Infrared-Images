﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing.Imaging;

    public class RotateBicubic : BaseRotateFilter
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;

        public RotateBicubic(double angle) : this(angle, false)
        {
        }

        public RotateBicubic(double angle, bool keepSize) : base(angle, keepSize)
        {
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage sourceData, UnmanagedImage destinationData)
        {
            double num17;
            double num18;
            double num19;
            double num20;
            double num21;
            double num22;
            double num23;
            double num24;
            int num25;
            int num26;
            int num27;
            int num28;
            double num30;
            int width = sourceData.Width;
            int height = sourceData.Height;
            double num3 = ((double) width) / 2.0;
            double num4 = ((double) height) / 2.0;
            int num5 = destinationData.Width;
            int num6 = destinationData.Height;
            double num7 = ((double) num5) / 2.0;
            double num8 = ((double) num6) / 2.0;
            double d = (-base.angle * 3.1415926535897931) / 180.0;
            double num10 = Math.Cos(d);
            double num11 = Math.Sin(d);
            int stride = sourceData.Stride;
            int num13 = destinationData.Stride - ((destinationData.PixelFormat == PixelFormat.Format8bppIndexed) ? num5 : (num5 * 3));
            byte r = this.fillColor.R;
            byte g = this.fillColor.G;
            byte b = this.fillColor.B;
            byte* numPtr = (byte*) sourceData.ImageData.ToPointer();
            byte* numPtr2 = (byte*) destinationData.ImageData.ToPointer();
            int num32 = height - 1;
            int num33 = width - 1;
            if (destinationData.PixelFormat == PixelFormat.Format8bppIndexed)
            {
                num18 = -num8;
                for (int i = 0; i < num6; i++)
                {
                    num17 = -num7;
                    int num35 = 0;
                    while (num35 < num5)
                    {
                        num19 = ((num10 * num17) + (num11 * num18)) + num3;
                        num20 = ((-num11 * num17) + (num10 * num18)) + num4;
                        num25 = (int) num19;
                        num26 = (int) num20;
                        if (((num25 < 0) || (num26 < 0)) || ((num25 >= width) || (num26 >= height)))
                        {
                            numPtr2[0] = g;
                        }
                        else
                        {
                            num21 = num19 - num25;
                            num22 = num20 - num26;
                            num30 = 0.0;
                            for (int j = -1; j < 3; j++)
                            {
                                num23 = Interpolation.BiCubicKernel(num22 - j);
                                num28 = num26 + j;
                                if (num28 < 0)
                                {
                                    num28 = 0;
                                }
                                if (num28 > num32)
                                {
                                    num28 = num32;
                                }
                                for (int k = -1; k < 3; k++)
                                {
                                    num24 = num23 * Interpolation.BiCubicKernel(k - num21);
                                    num27 = num25 + k;
                                    if (num27 < 0)
                                    {
                                        num27 = 0;
                                    }
                                    if (num27 > num33)
                                    {
                                        num27 = num33;
                                    }
                                    num30 += num24 * numPtr[(num28 * stride) + num27];
                                }
                            }
                            numPtr2[0] = (byte) Math.Max(0.0, Math.Min(255.0, num30));
                        }
                        num17++;
                        num35++;
                        numPtr2++;
                    }
                    num18++;
                    numPtr2 += num13;
                }
            }
            else
            {
                num18 = -num8;
                for (int m = 0; m < num6; m++)
                {
                    num17 = -num7;
                    int num39 = 0;
                    while (num39 < num5)
                    {
                        num19 = ((num10 * num17) + (num11 * num18)) + num3;
                        num20 = ((-num11 * num17) + (num10 * num18)) + num4;
                        num25 = (int) num19;
                        num26 = (int) num20;
                        if (((num25 < 0) || (num26 < 0)) || ((num25 >= width) || (num26 >= height)))
                        {
                            numPtr2[2] = r;
                            numPtr2[1] = g;
                            numPtr2[0] = b;
                        }
                        else
                        {
                            double num31;
                            num21 = num19 - num25;
                            num22 = num20 - num26;
                            double num29 = num30 = num31 = 0.0;
                            for (int n = -1; n < 3; n++)
                            {
                                num23 = Interpolation.BiCubicKernel(num22 - n);
                                num28 = num26 + n;
                                if (num28 < 0)
                                {
                                    num28 = 0;
                                }
                                if (num28 > num32)
                                {
                                    num28 = num32;
                                }
                                for (int num41 = -1; num41 < 3; num41++)
                                {
                                    num24 = num23 * Interpolation.BiCubicKernel(num41 - num21);
                                    num27 = num25 + num41;
                                    if (num27 < 0)
                                    {
                                        num27 = 0;
                                    }
                                    if (num27 > num33)
                                    {
                                        num27 = num33;
                                    }
                                    byte* numPtr3 = (numPtr + (num28 * stride)) + (num27 * 3);
                                    num29 += num24 * numPtr3[2];
                                    num30 += num24 * numPtr3[1];
                                    num31 += num24 * numPtr3[0];
                                }
                            }
                            numPtr2[2] = (byte) Math.Max(0.0, Math.Min(255.0, num29));
                            numPtr2[1] = (byte) Math.Max(0.0, Math.Min(255.0, num30));
                            numPtr2[0] = (byte) Math.Max(0.0, Math.Min(255.0, num31));
                        }
                        num17++;
                        num39++;
                        numPtr2 += 3;
                    }
                    num18++;
                    numPtr2 += num13;
                }
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }
    }
}

