﻿namespace AForge.Imaging.Filters
{
    using AForge;
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class SimpleQuadrilateralTransformation : BaseTransformationFilter
    {
        private bool automaticSizeCalculaton;
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;
        protected int newHeight;
        protected int newWidth;
        private List<IntPoint> sourceQuadrilateral;
        private bool useInterpolation;

        public SimpleQuadrilateralTransformation()
        {
            this.automaticSizeCalculaton = true;
            this.useInterpolation = true;
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
            this.formatTranslations[PixelFormat.Format32bppRgb] = PixelFormat.Format32bppRgb;
            this.formatTranslations[PixelFormat.Format32bppArgb] = PixelFormat.Format32bppArgb;
            this.formatTranslations[PixelFormat.Format32bppPArgb] = PixelFormat.Format32bppPArgb;
        }

        public SimpleQuadrilateralTransformation(List<IntPoint> sourceQuadrilateral) : this()
        {
            this.automaticSizeCalculaton = true;
            this.sourceQuadrilateral = sourceQuadrilateral;
            this.CalculateDestinationSize();
        }

        public SimpleQuadrilateralTransformation(List<IntPoint> sourceQuadrilateral, int newWidth, int newHeight) : this()
        {
            this.automaticSizeCalculaton = false;
            this.sourceQuadrilateral = sourceQuadrilateral;
            this.newWidth = newWidth;
            this.newHeight = newHeight;
        }

        private void CalculateDestinationSize()
        {
            if (this.sourceQuadrilateral == null)
            {
                throw new NullReferenceException("Source quadrilateral was not set.");
            }
            IntPoint point = this.sourceQuadrilateral[0];
            IntPoint point2 = this.sourceQuadrilateral[2];
            this.newWidth = (int) Math.Max(point.DistanceTo(this.sourceQuadrilateral[1]), point2.DistanceTo(this.sourceQuadrilateral[3]));
            IntPoint point3 = this.sourceQuadrilateral[1];
            IntPoint point4 = this.sourceQuadrilateral[3];
            this.newHeight = (int) Math.Max(point3.DistanceTo(this.sourceQuadrilateral[2]), point4.DistanceTo(this.sourceQuadrilateral[0]));
        }

        protected override Size CalculateNewImageSize(UnmanagedImage sourceData)
        {
            if (this.sourceQuadrilateral == null)
            {
                throw new NullReferenceException("Source quadrilateral was not set.");
            }
            return new Size(this.newWidth, this.newHeight);
        }

        protected override unsafe void ProcessFilter(UnmanagedImage sourceData, UnmanagedImage destinationData)
        {
            double num8;
            double num9;
            double num10;
            double num11;
            double num12;
            double num13;
            int width = sourceData.Width;
            int height = sourceData.Height;
            int num3 = destinationData.Width;
            int num4 = destinationData.Height;
            int num5 = Image.GetPixelFormatSize(sourceData.PixelFormat) / 8;
            int stride = sourceData.Stride;
            int num7 = destinationData.Stride;
            if (this.sourceQuadrilateral[1].X == this.sourceQuadrilateral[0].X)
            {
                num8 = 0.0;
                int x = this.sourceQuadrilateral[1].X;
            }
            else
            {
                num8 = ((double) (this.sourceQuadrilateral[1].Y - this.sourceQuadrilateral[0].Y)) / ((double) (this.sourceQuadrilateral[1].X - this.sourceQuadrilateral[0].X));
                int num44 = this.sourceQuadrilateral[0].Y;
                int num45 = this.sourceQuadrilateral[0].X;
            }
            if (this.sourceQuadrilateral[2].X == this.sourceQuadrilateral[3].X)
            {
                num9 = 0.0;
                int num46 = this.sourceQuadrilateral[2].X;
            }
            else
            {
                num9 = ((double) (this.sourceQuadrilateral[2].Y - this.sourceQuadrilateral[3].Y)) / ((double) (this.sourceQuadrilateral[2].X - this.sourceQuadrilateral[3].X));
                int num47 = this.sourceQuadrilateral[3].Y;
                int num48 = this.sourceQuadrilateral[3].X;
            }
            if (this.sourceQuadrilateral[3].X == this.sourceQuadrilateral[0].X)
            {
                num10 = 0.0;
                num11 = this.sourceQuadrilateral[3].X;
            }
            else
            {
                num10 = ((double) (this.sourceQuadrilateral[3].Y - this.sourceQuadrilateral[0].Y)) / ((double) (this.sourceQuadrilateral[3].X - this.sourceQuadrilateral[0].X));
                num11 = this.sourceQuadrilateral[0].Y - (num10 * this.sourceQuadrilateral[0].X);
            }
            if (this.sourceQuadrilateral[2].X == this.sourceQuadrilateral[1].X)
            {
                num12 = 0.0;
                num13 = this.sourceQuadrilateral[2].X;
            }
            else
            {
                num12 = ((double) (this.sourceQuadrilateral[2].Y - this.sourceQuadrilateral[1].Y)) / ((double) (this.sourceQuadrilateral[2].X - this.sourceQuadrilateral[1].X));
                num13 = this.sourceQuadrilateral[1].Y - (num12 * this.sourceQuadrilateral[1].X);
            }
            double num14 = ((double) (this.sourceQuadrilateral[3].Y - this.sourceQuadrilateral[0].Y)) / ((double) num4);
            double num15 = ((double) (this.sourceQuadrilateral[2].Y - this.sourceQuadrilateral[1].Y)) / ((double) num4);
            int y = this.sourceQuadrilateral[0].Y;
            int num17 = this.sourceQuadrilateral[1].Y;
            byte* numPtr = (byte*) sourceData.ImageData.ToPointer();
            byte* numPtr2 = (byte*) destinationData.ImageData.ToPointer();
            int num18 = height - 1;
            int num19 = width - 1;
            for (int i = 0; i < num4; i++)
            {
                double num33;
                double num34;
                byte* numPtr8 = numPtr2 + (num7 * i);
                double num29 = (num14 * i) + y;
                double num30 = (num10 == 0.0) ? num11 : ((num29 - num11) / num10);
                double num31 = (num15 * i) + num17;
                double num32 = (num12 == 0.0) ? num13 : ((num31 - num13) / num12);
                if (num30 == num32)
                {
                    num33 = 0.0;
                    num34 = num32;
                }
                else
                {
                    num33 = (num31 - num29) / (num32 - num30);
                    num34 = num29 - (num33 * num30);
                }
                double num35 = (num32 - num30) / ((double) num3);
                if (!this.useInterpolation)
                {
                    for (int j = 0; j < num3; j++)
                    {
                        double num37 = (num35 * j) + num30;
                        double num38 = (num33 * num37) + num34;
                        if (((num37 >= 0.0) && (num38 >= 0.0)) && ((num37 < width) && (num38 < height)))
                        {
                            byte* numPtr7 = numPtr + ((((int) num38) * stride) + (((int) num37) * num5));
                            int num39 = 0;
                            while (num39 < num5)
                            {
                                numPtr8[0] = numPtr7[0];
                                num39++;
                                numPtr8++;
                                numPtr7++;
                            }
                        }
                        else
                        {
                            numPtr8 += num5;
                        }
                    }
                }
                else
                {
                    for (int k = 0; k < num3; k++)
                    {
                        double num41 = (num35 * k) + num30;
                        double num42 = (num33 * num41) + num34;
                        if (((num41 >= 0.0) && (num42 >= 0.0)) && ((num41 < width) && (num42 < height)))
                        {
                            byte* numPtr4;
                            byte* numPtr6;
                            int num24 = (int) num41;
                            int num26 = (num24 == num19) ? num24 : (num24 + 1);
                            double num20 = num41 - num24;
                            double num22 = 1.0 - num20;
                            int num25 = (int) num42;
                            int num27 = (num25 == num18) ? num25 : (num25 + 1);
                            double num21 = num42 - num25;
                            double num23 = 1.0 - num21;
                            byte* numPtr3 = numPtr4 = numPtr + (num25 * stride);
                            numPtr3 += num24 * num5;
                            numPtr4 += num26 * num5;
                            byte* numPtr5 = numPtr6 = numPtr + (num27 * stride);
                            numPtr5 += num24 * num5;
                            numPtr6 += num26 * num5;
                            int num43 = 0;
                            while (num43 < num5)
                            {
                                numPtr8[0] = (byte) ((num23 * ((num22 * numPtr3[0]) + (num20 * numPtr4[0]))) + (num21 * ((num22 * numPtr5[0]) + (num20 * numPtr6[0]))));
                                num43++;
                                numPtr8++;
                                numPtr3++;
                                numPtr4++;
                                numPtr5++;
                                numPtr6++;
                            }
                        }
                        else
                        {
                            numPtr8 += num5;
                        }
                    }
                }
            }
        }

        public bool AutomaticSizeCalculaton
        {
            get
            {
                return this.automaticSizeCalculaton;
            }
            set
            {
                this.automaticSizeCalculaton = value;
                if (value)
                {
                    this.CalculateDestinationSize();
                }
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public int NewHeight
        {
            get
            {
                return this.newHeight;
            }
            set
            {
                if (!this.automaticSizeCalculaton)
                {
                    this.newHeight = Math.Max(1, value);
                }
            }
        }

        public int NewWidth
        {
            get
            {
                return this.newWidth;
            }
            set
            {
                if (!this.automaticSizeCalculaton)
                {
                    this.newWidth = Math.Max(1, value);
                }
            }
        }

        public List<IntPoint> SourceQuadrilateral
        {
            get
            {
                return this.sourceQuadrilateral;
            }
            set
            {
                this.sourceQuadrilateral = value;
                if (this.automaticSizeCalculaton)
                {
                    this.CalculateDestinationSize();
                }
            }
        }

        public bool UseInterpolation
        {
            get
            {
                return this.useInterpolation;
            }
            set
            {
                this.useInterpolation = value;
            }
        }
    }
}

