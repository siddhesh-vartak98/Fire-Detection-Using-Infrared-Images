﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class ResizeBilinear : BaseResizeFilter
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;

        public ResizeBilinear(int newWidth, int newHeight) : base(newWidth, newHeight)
        {
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
            this.formatTranslations[PixelFormat.Format32bppRgb] = PixelFormat.Format32bppRgb;
            this.formatTranslations[PixelFormat.Format32bppArgb] = PixelFormat.Format32bppArgb;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage sourceData, UnmanagedImage destinationData)
        {
            int width = sourceData.Width;
            int height = sourceData.Height;
            int num3 = Image.GetPixelFormatSize(sourceData.PixelFormat) / 8;
            int stride = sourceData.Stride;
            int num5 = destinationData.Stride - (num3 * base.newWidth);
            double num6 = ((double) width) / ((double) base.newWidth);
            double num7 = ((double) height) / ((double) base.newHeight);
            byte* numPtr = (byte*) sourceData.ImageData.ToPointer();
            byte* numPtr2 = (byte*) destinationData.ImageData.ToPointer();
            int num18 = height - 1;
            int num19 = width - 1;
            for (int i = 0; i < base.newHeight; i++)
            {
                double num9 = i * num7;
                int num15 = (int) num9;
                int num17 = (num15 == num18) ? num15 : (num15 + 1);
                double num11 = num9 - num15;
                double num13 = 1.0 - num11;
                byte* numPtr3 = numPtr + (num15 * stride);
                byte* numPtr4 = numPtr + (num17 * stride);
                for (int j = 0; j < base.newWidth; j++)
                {
                    double num8 = j * num6;
                    int num14 = (int) num8;
                    int num16 = (num14 == num19) ? num14 : (num14 + 1);
                    double num10 = num8 - num14;
                    double num12 = 1.0 - num10;
                    byte* numPtr5 = numPtr3 + (num14 * num3);
                    byte* numPtr6 = numPtr3 + (num16 * num3);
                    byte* numPtr7 = numPtr4 + (num14 * num3);
                    byte* numPtr8 = numPtr4 + (num16 * num3);
                    int num22 = 0;
                    while (num22 < num3)
                    {
                        numPtr2[0] = (byte) ((num13 * ((num12 * numPtr5[0]) + (num10 * numPtr6[0]))) + (num11 * ((num12 * numPtr7[0]) + (num10 * numPtr8[0]))));
                        num22++;
                        numPtr2++;
                        numPtr5++;
                        numPtr6++;
                        numPtr7++;
                        numPtr8++;
                    }
                }
                numPtr2 += num5;
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }
    }
}

