﻿namespace AForge.Imaging.Filters
{
    using AForge;
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class YCbCrFiltering : BaseInPlacePartialFilter
    {
        private DoubleRange cbRange;
        private DoubleRange crRange;
        private double fillCb;
        private double fillCr;
        private bool fillOutsideRange;
        private double fillY;
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;
        private bool updateCb;
        private bool updateCr;
        private bool updateY;
        private DoubleRange yRange;

        public YCbCrFiltering()
        {
            this.yRange = new DoubleRange(0.0, 1.0);
            this.cbRange = new DoubleRange(-0.5, 0.5);
            this.crRange = new DoubleRange(-0.5, 0.5);
            this.fillOutsideRange = true;
            this.updateY = true;
            this.updateCb = true;
            this.updateCr = true;
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
            this.formatTranslations[PixelFormat.Format32bppRgb] = PixelFormat.Format32bppRgb;
            this.formatTranslations[PixelFormat.Format32bppArgb] = PixelFormat.Format32bppArgb;
        }

        public YCbCrFiltering(DoubleRange yRange, DoubleRange cbRange, DoubleRange crRange) : this()
        {
            this.yRange = yRange;
            this.cbRange = cbRange;
            this.crRange = crRange;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage image, Rectangle rect)
        {
            int num = (image.PixelFormat == PixelFormat.Format24bppRgb) ? 3 : 4;
            int left = rect.Left;
            int top = rect.Top;
            int num4 = left + rect.Width;
            int num5 = top + rect.Height;
            int num6 = image.Stride - (rect.Width * num);
            RGB rgb = new RGB();
            YCbCr ycbcr = new YCbCr();
            byte* numPtr = (byte*) (image.ImageData.ToPointer() + ((top * image.Stride) + (left * num)));
            for (int i = top; i < num5; i++)
            {
                int num8 = left;
                while (num8 < num4)
                {
                    bool flag = false;
                    rgb.Red = numPtr[2];
                    rgb.Green = numPtr[1];
                    rgb.Blue = numPtr[0];
                    YCbCr.FromRGB(rgb, ycbcr);
                    if ((((ycbcr.Y >= this.yRange.Min) && (ycbcr.Y <= this.yRange.Max)) && ((ycbcr.Cb >= this.cbRange.Min) && (ycbcr.Cb <= this.cbRange.Max))) && ((ycbcr.Cr >= this.crRange.Min) && (ycbcr.Cr <= this.crRange.Max)))
                    {
                        if (!this.fillOutsideRange)
                        {
                            if (this.updateY)
                            {
                                ycbcr.Y = this.fillY;
                            }
                            if (this.updateCb)
                            {
                                ycbcr.Cb = this.fillCb;
                            }
                            if (this.updateCr)
                            {
                                ycbcr.Cr = this.fillCr;
                            }
                            flag = true;
                        }
                    }
                    else if (this.fillOutsideRange)
                    {
                        if (this.updateY)
                        {
                            ycbcr.Y = this.fillY;
                        }
                        if (this.updateCb)
                        {
                            ycbcr.Cb = this.fillCb;
                        }
                        if (this.updateCr)
                        {
                            ycbcr.Cr = this.fillCr;
                        }
                        flag = true;
                    }
                    if (flag)
                    {
                        YCbCr.ToRGB(ycbcr, rgb);
                        numPtr[2] = rgb.Red;
                        numPtr[1] = rgb.Green;
                        numPtr[0] = rgb.Blue;
                    }
                    num8++;
                    numPtr += num;
                }
                numPtr += num6;
            }
        }

        public DoubleRange Cb
        {
            get
            {
                return this.cbRange;
            }
            set
            {
                this.cbRange = value;
            }
        }

        public DoubleRange Cr
        {
            get
            {
                return this.crRange;
            }
            set
            {
                this.crRange = value;
            }
        }

        public YCbCr FillColor
        {
            get
            {
                return new YCbCr(this.fillY, this.fillCb, this.fillCr);
            }
            set
            {
                this.fillY = value.Y;
                this.fillCb = value.Cb;
                this.fillCr = value.Cr;
            }
        }

        public bool FillOutsideRange
        {
            get
            {
                return this.fillOutsideRange;
            }
            set
            {
                this.fillOutsideRange = value;
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public bool UpdateCb
        {
            get
            {
                return this.updateCb;
            }
            set
            {
                this.updateCb = value;
            }
        }

        public bool UpdateCr
        {
            get
            {
                return this.updateCr;
            }
            set
            {
                this.updateCr = value;
            }
        }

        public bool UpdateY
        {
            get
            {
                return this.updateY;
            }
            set
            {
                this.updateY = value;
            }
        }

        public DoubleRange Y
        {
            get
            {
                return this.yRange;
            }
            set
            {
                this.yRange = value;
            }
        }
    }
}

