﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class SISThreshold : BaseInPlacePartialFilter
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
        private Threshold thresholdFilter = new Threshold();

        public SISThreshold()
        {
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
        }

        public unsafe int CalculateThreshold(UnmanagedImage image, Rectangle rect)
        {
            if (image.PixelFormat != PixelFormat.Format8bppIndexed)
            {
                throw new UnsupportedImageFormatException("Source pixel format is not supported by the routine.");
            }
            int left = rect.Left;
            int top = rect.Top;
            int num3 = left + rect.Width;
            int num4 = top + rect.Height;
            int num5 = num3 - 1;
            int num6 = num4 - 1;
            int stride = image.Stride;
            int num8 = stride - rect.Width;
            double num12 = 0.0;
            double num13 = 0.0;
            byte* numPtr = (byte*) (image.ImageData.ToPointer() + ((top * image.Stride) + left));
            numPtr += stride;
            for (int i = top + 1; i < num6; i++)
            {
                numPtr++;
                int num15 = left + 1;
                while (num15 < num5)
                {
                    double num9 = Math.Abs((int) (numPtr[1] - numPtr[-1]));
                    double num10 = Math.Abs((int) (numPtr[stride] - numPtr[-stride]));
                    double num11 = (num9 > num10) ? num9 : num10;
                    num12 += num11;
                    num13 += num11 * numPtr[0];
                    num15++;
                    numPtr++;
                }
                numPtr += num8 + 1;
            }
            if (num12 != 0.0)
            {
                return (byte) (num13 / num12);
            }
            return 0;
        }

        public int CalculateThreshold(Bitmap image, Rectangle rect)
        {
            int num = 0;
            BitmapData data = image.LockBits(new Rectangle(0, 0, image.Width, image.Height), ImageLockMode.ReadOnly, image.PixelFormat);
            try
            {
                num = this.CalculateThreshold(data, rect);
            }
            finally
            {
                image.UnlockBits(data);
            }
            return num;
        }

        public int CalculateThreshold(BitmapData image, Rectangle rect)
        {
            return this.CalculateThreshold(new UnmanagedImage(image), rect);
        }

        protected override void ProcessFilter(UnmanagedImage image, Rectangle rect)
        {
            this.thresholdFilter.ThresholdValue = this.CalculateThreshold(image, rect);
            this.thresholdFilter.ApplyInPlace(image, rect);
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public int ThresholdValue
        {
            get
            {
                return this.thresholdFilter.ThresholdValue;
            }
        }
    }
}

