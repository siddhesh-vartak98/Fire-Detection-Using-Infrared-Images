﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing.Imaging;

    public class StereoAnaglyph : BaseInPlaceFilter2
    {
        private Algorithm anaglyphAlgorithm;
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;

        public StereoAnaglyph()
        {
            this.anaglyphAlgorithm = Algorithm.GrayAnaglyph;
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
        }

        public StereoAnaglyph(Algorithm anaglyphAlgorithm) : this()
        {
            this.anaglyphAlgorithm = anaglyphAlgorithm;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage image, UnmanagedImage overlay)
        {
            int num13;
            int width = image.Width;
            int height = image.Height;
            int num3 = image.Stride - (width * 3);
            int num4 = overlay.Stride - (width * 3);
            byte* numPtr = (byte*) image.ImageData.ToPointer();
            byte* numPtr2 = (byte*) overlay.ImageData.ToPointer();
            switch (this.anaglyphAlgorithm)
            {
                case Algorithm.TrueAnaglyph:
                    for (int i = 0; i < height; i++)
                    {
                        int num6 = 0;
                        while (num6 < width)
                        {
                            numPtr[2] = (byte) (((numPtr[2] * 0.299) + (numPtr[1] * 0.587)) + (numPtr[0] * 0.114));
                            numPtr[1] = 0;
                            numPtr[0] = (byte) (((numPtr2[2] * 0.299) + (numPtr2[1] * 0.587)) + (numPtr2[0] * 0.114));
                            num6++;
                            numPtr += 3;
                            numPtr2 += 3;
                        }
                        numPtr += num3;
                        numPtr2 += num4;
                    }
                    return;

                case Algorithm.GrayAnaglyph:
                    for (int j = 0; j < height; j++)
                    {
                        int num8 = 0;
                        while (num8 < width)
                        {
                            numPtr[2] = (byte) (((numPtr[2] * 0.299) + (numPtr[1] * 0.587)) + (numPtr[0] * 0.114));
                            numPtr[1] = (byte) (((numPtr2[2] * 0.299) + (numPtr2[1] * 0.587)) + (numPtr2[0] * 0.114));
                            numPtr[0] = numPtr[1];
                            num8++;
                            numPtr += 3;
                            numPtr2 += 3;
                        }
                        numPtr += num3;
                        numPtr2 += num4;
                    }
                    return;

                case Algorithm.ColorAnaglyph:
                    for (int k = 0; k < height; k++)
                    {
                        int num10 = 0;
                        while (num10 < width)
                        {
                            numPtr[1] = numPtr2[1];
                            numPtr[0] = numPtr2[0];
                            num10++;
                            numPtr += 3;
                            numPtr2 += 3;
                        }
                        numPtr += num3;
                        numPtr2 += num4;
                    }
                    return;

                case Algorithm.HalfColorAnaglyph:
                    for (int m = 0; m < height; m++)
                    {
                        int num12 = 0;
                        while (num12 < width)
                        {
                            numPtr[2] = (byte) (((numPtr[2] * 0.299) + (numPtr[1] * 0.587)) + (numPtr[0] * 0.114));
                            numPtr[1] = numPtr2[1];
                            numPtr[0] = numPtr2[0];
                            num12++;
                            numPtr += 3;
                            numPtr2 += 3;
                        }
                        numPtr += num3;
                        numPtr2 += num4;
                    }
                    return;

                case Algorithm.OptimizedAnaglyph:
                    num13 = 0;
                    break;

                default:
                    return;
            }
            while (num13 < height)
            {
                int num14 = 0;
                while (num14 < width)
                {
                    numPtr[2] = (byte) ((numPtr[1] * 0.7) + (numPtr[0] * 0.3));
                    numPtr[1] = numPtr2[1];
                    numPtr[0] = numPtr2[0];
                    num14++;
                    numPtr += 3;
                    numPtr2 += 3;
                }
                numPtr += num3;
                numPtr2 += num4;
                num13++;
            }
        }

        public Algorithm AnaglyphAlgorithm
        {
            get
            {
                return this.anaglyphAlgorithm;
            }
            set
            {
                this.anaglyphAlgorithm = value;
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public enum Algorithm
        {
            TrueAnaglyph,
            GrayAnaglyph,
            ColorAnaglyph,
            HalfColorAnaglyph,
            OptimizedAnaglyph
        }
    }
}

