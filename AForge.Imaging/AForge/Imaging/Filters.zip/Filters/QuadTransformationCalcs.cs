﻿namespace AForge.Imaging.Filters
{
    using System;
    using System.Collections.Generic;

    internal static class QuadTransformationCalcs
    {
        private const double TOLERANCE = 1E-13;

        private static double[,] AdjugateMatrix(double[,] a)
        {
            double[,] numArray = new double[3, 3];
            numArray[0, 0] = Det2(a[1, 1], a[1, 2], a[2, 1], a[2, 2]);
            numArray[1, 0] = Det2(a[1, 2], a[1, 0], a[2, 2], a[2, 0]);
            numArray[2, 0] = Det2(a[1, 0], a[1, 1], a[2, 0], a[2, 1]);
            numArray[0, 1] = Det2(a[2, 1], a[2, 2], a[0, 1], a[0, 2]);
            numArray[1, 1] = Det2(a[2, 2], a[2, 0], a[0, 2], a[0, 0]);
            numArray[2, 1] = Det2(a[2, 0], a[2, 1], a[0, 0], a[0, 1]);
            numArray[0, 2] = Det2(a[0, 1], a[0, 2], a[1, 1], a[1, 2]);
            numArray[1, 2] = Det2(a[0, 2], a[0, 0], a[1, 2], a[1, 0]);
            numArray[2, 2] = Det2(a[0, 0], a[0, 1], a[1, 0], a[1, 1]);
            return numArray;
        }

        private static double Det2(double a, double b, double c, double d)
        {
            return ((a * d) - (b * c));
        }

        public static double[,] MapQuadToQuad(List<IntPoint> input, List<IntPoint> output)
        {
            double[,] a = MapSquareToQuad(input);
            double[,] numArray2 = MapSquareToQuad(output);
            if (numArray2 == null)
            {
                return null;
            }
            return MultiplyMatrix(numArray2, AdjugateMatrix(a));
        }

        private static double[,] MapSquareToQuad(List<IntPoint> quad)
        {
            double[,] numArray = new double[3, 3];
            double a = ((quad[0].X - quad[1].X) + quad[2].X) - quad[3].X;
            double c = ((quad[0].Y - quad[1].Y) + quad[2].Y) - quad[3].Y;
            if (((a < 1E-13) && (a > -1E-13)) && ((c < 1E-13) && (c > -1E-13)))
            {
                numArray[0, 0] = quad[1].X - quad[0].X;
                numArray[0, 1] = quad[2].X - quad[1].X;
                numArray[0, 2] = quad[0].X;
                numArray[1, 0] = quad[1].Y - quad[0].Y;
                numArray[1, 1] = quad[2].Y - quad[1].Y;
                numArray[1, 2] = quad[0].Y;
                numArray[2, 0] = 0.0;
                numArray[2, 1] = 0.0;
                numArray[2, 2] = 1.0;
                return numArray;
            }
            double num3 = quad[1].X - quad[2].X;
            double b = quad[3].X - quad[2].X;
            double num5 = quad[1].Y - quad[2].Y;
            double d = quad[3].Y - quad[2].Y;
            double num7 = Det2(num3, b, num5, d);
            if (num7 == 0.0)
            {
                return null;
            }
            numArray[2, 0] = Det2(a, b, c, d) / num7;
            numArray[2, 1] = Det2(num3, a, num5, c) / num7;
            numArray[2, 2] = 1.0;
            numArray[0, 0] = (quad[1].X - quad[0].X) + (numArray[2, 0] * quad[1].X);
            numArray[0, 1] = (quad[3].X - quad[0].X) + (numArray[2, 1] * quad[3].X);
            numArray[0, 2] = quad[0].X;
            numArray[1, 0] = (quad[1].Y - quad[0].Y) + (numArray[2, 0] * quad[1].Y);
            numArray[1, 1] = (quad[3].Y - quad[0].Y) + (numArray[2, 1] * quad[3].Y);
            numArray[1, 2] = quad[0].Y;
            return numArray;
        }

        private static double[,] MultiplyMatrix(double[,] a, double[,] b)
        {
            return new double[,] { { (((a[0, 0] * b[0, 0]) + (a[0, 1] * b[1, 0])) + (a[0, 2] * b[2, 0])), (((a[0, 0] * b[0, 1]) + (a[0, 1] * b[1, 1])) + (a[0, 2] * b[2, 1])), (((a[0, 0] * b[0, 2]) + (a[0, 1] * b[1, 2])) + (a[0, 2] * b[2, 2])) }, { (((a[1, 0] * b[0, 0]) + (a[1, 1] * b[1, 0])) + (a[1, 2] * b[2, 0])), (((a[1, 0] * b[0, 1]) + (a[1, 1] * b[1, 1])) + (a[1, 2] * b[2, 1])), (((a[1, 0] * b[0, 2]) + (a[1, 1] * b[1, 2])) + (a[1, 2] * b[2, 2])) }, { (((a[2, 0] * b[0, 0]) + (a[2, 1] * b[1, 0])) + (a[2, 2] * b[2, 0])), (((a[2, 0] * b[0, 1]) + (a[2, 1] * b[1, 1])) + (a[2, 2] * b[2, 1])), (((a[2, 0] * b[0, 2]) + (a[2, 1] * b[1, 2])) + (a[2, 2] * b[2, 2])) } };
        }
    }
}

