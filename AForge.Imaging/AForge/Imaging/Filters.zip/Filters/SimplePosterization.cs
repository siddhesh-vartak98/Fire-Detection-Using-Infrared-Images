﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class SimplePosterization : BaseInPlacePartialFilter
    {
        private PosterizationFillingType fillingType;
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;
        private byte posterizationInterval;

        public SimplePosterization()
        {
            this.posterizationInterval = 0x40;
            this.fillingType = PosterizationFillingType.Average;
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format32bppRgb] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format32bppArgb] = PixelFormat.Format8bppIndexed;
        }

        public SimplePosterization(PosterizationFillingType fillingType) : this()
        {
            this.fillingType = fillingType;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage image, Rectangle rect)
        {
            int num = Image.GetPixelFormatSize(image.PixelFormat) / 8;
            int left = rect.Left;
            int top = rect.Top;
            int num4 = left + rect.Width;
            int num5 = top + rect.Height;
            int num6 = image.Stride - (rect.Width * num);
            int num7 = (this.fillingType == PosterizationFillingType.Min) ? 0 : ((this.fillingType == PosterizationFillingType.Max) ? (this.posterizationInterval - 1) : (this.posterizationInterval / 2));
            byte[] buffer = new byte[0x100];
            for (int i = 0; i < 0x100; i++)
            {
                buffer[i] = (byte) Math.Min(0xff, ((i / this.posterizationInterval) * this.posterizationInterval) + num7);
            }
            byte* numPtr = (byte*) (image.ImageData.ToPointer() + ((top * image.Stride) + (left * num)));
            if (image.PixelFormat == PixelFormat.Format8bppIndexed)
            {
                for (int j = top; j < num5; j++)
                {
                    int num10 = left;
                    while (num10 < num4)
                    {
                        numPtr[0] = buffer[numPtr[0]];
                        num10++;
                        numPtr++;
                    }
                    numPtr += num6;
                }
            }
            else
            {
                for (int k = top; k < num5; k++)
                {
                    int num12 = left;
                    while (num12 < num4)
                    {
                        numPtr[2] = buffer[numPtr[2]];
                        numPtr[1] = buffer[numPtr[1]];
                        numPtr[0] = buffer[numPtr[0]];
                        num12++;
                        numPtr += num;
                    }
                    numPtr += num6;
                }
            }
        }

        public PosterizationFillingType FillingType
        {
            get
            {
                return this.fillingType;
            }
            set
            {
                this.fillingType = value;
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public byte PosterizationInterval
        {
            get
            {
                return this.posterizationInterval;
            }
            set
            {
                this.posterizationInterval = value;
            }
        }

        public enum PosterizationFillingType
        {
            Min,
            Max,
            Average
        }
    }
}

