﻿namespace AForge.Imaging.Filters
{
    using System;

    public sealed class Sharpen : Convolution
    {
        public Sharpen() : base(new int[,] { { 0, -1, 0 }, { -1, 5, -1 }, { 0, -1, 0 } })
        {
        }
    }
}

