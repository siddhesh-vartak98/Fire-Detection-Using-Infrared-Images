﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class ThresholdedDifference : BaseFilter2
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;
        private int threshold;
        private int whitePixelsCount;

        public ThresholdedDifference()
        {
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.threshold = 15;
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format32bppRgb] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format32bppArgb] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format32bppPArgb] = PixelFormat.Format8bppIndexed;
        }

        public ThresholdedDifference(int threshold) : this()
        {
            this.threshold = threshold;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage sourceData, UnmanagedImage overlay, UnmanagedImage destinationData)
        {
            this.whitePixelsCount = 0;
            int width = sourceData.Width;
            int height = sourceData.Height;
            int num3 = Image.GetPixelFormatSize(sourceData.PixelFormat) / 8;
            byte* numPtr = (byte*) sourceData.ImageData.ToPointer();
            byte* numPtr2 = (byte*) overlay.ImageData.ToPointer();
            byte* numPtr3 = (byte*) destinationData.ImageData.ToPointer();
            if (num3 == 1)
            {
                int num4 = sourceData.Stride - width;
                int num5 = overlay.Stride - width;
                int num6 = destinationData.Stride - width;
                for (int i = 0; i < height; i++)
                {
                    int num8 = 0;
                    while (num8 < width)
                    {
                        int num9 = numPtr[0] - numPtr2[0];
                        if (num9 < 0)
                        {
                            num9 = -num9;
                        }
                        if (num9 > this.threshold)
                        {
                            numPtr3[0] = 0xff;
                            this.whitePixelsCount++;
                        }
                        else
                        {
                            numPtr3[0] = 0;
                        }
                        num8++;
                        numPtr++;
                        numPtr2++;
                        numPtr3++;
                    }
                    numPtr += num4;
                    numPtr2 += num5;
                    numPtr3 += num6;
                }
            }
            else
            {
                int num10 = sourceData.Stride - (num3 * width);
                int num11 = overlay.Stride - (num3 * width);
                int num12 = destinationData.Stride - width;
                for (int j = 0; j < height; j++)
                {
                    int num14 = 0;
                    while (num14 < width)
                    {
                        int num15 = numPtr[2] - numPtr2[2];
                        int num16 = numPtr[1] - numPtr2[1];
                        int num17 = numPtr[0] - numPtr2[0];
                        if (num15 < 0)
                        {
                            num15 = -num15;
                        }
                        if (num16 < 0)
                        {
                            num16 = -num16;
                        }
                        if (num17 < 0)
                        {
                            num17 = -num17;
                        }
                        if (((num15 + num16) + num17) > this.threshold)
                        {
                            numPtr3[0] = 0xff;
                            this.whitePixelsCount++;
                        }
                        else
                        {
                            numPtr3[0] = 0;
                        }
                        num14++;
                        numPtr += num3;
                        numPtr2 += num3;
                        numPtr3++;
                    }
                    numPtr += num10;
                    numPtr2 += num11;
                    numPtr3 += num12;
                }
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public int Threshold
        {
            get
            {
                return this.threshold;
            }
            set
            {
                this.threshold = value;
            }
        }

        public int WhitePixelsCount
        {
            get
            {
                return this.whitePixelsCount;
            }
        }
    }
}

