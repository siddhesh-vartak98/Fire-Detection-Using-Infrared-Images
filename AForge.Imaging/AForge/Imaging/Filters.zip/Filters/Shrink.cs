﻿namespace AForge.Imaging.Filters
{
    using AForge;
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class Shrink : BaseTransformationFilter
    {
        private Color colorToRemove;
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;
        private int minX;
        private int minY;

        public Shrink()
        {
            this.colorToRemove = Color.FromArgb(0, 0, 0);
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
        }

        public Shrink(Color colorToRemove) : this()
        {
            this.colorToRemove = colorToRemove;
        }

        protected override unsafe Size CalculateNewImageSize(UnmanagedImage sourceData)
        {
            int width = sourceData.Width;
            int height = sourceData.Height;
            int num3 = sourceData.Stride - ((sourceData.PixelFormat == PixelFormat.Format8bppIndexed) ? width : (width * 3));
            byte r = this.colorToRemove.R;
            byte g = this.colorToRemove.G;
            byte b = this.colorToRemove.B;
            this.minX = width;
            this.minY = height;
            int num7 = 0;
            int num8 = 0;
            byte* numPtr = (byte*) sourceData.ImageData.ToPointer();
            if (sourceData.PixelFormat == PixelFormat.Format8bppIndexed)
            {
                for (int i = 0; i < height; i++)
                {
                    int num10 = 0;
                    while (num10 < width)
                    {
                        if (numPtr[0] != g)
                        {
                            if (num10 < this.minX)
                            {
                                this.minX = num10;
                            }
                            if (num10 > num7)
                            {
                                num7 = num10;
                            }
                            if (i < this.minY)
                            {
                                this.minY = i;
                            }
                            if (i > num8)
                            {
                                num8 = i;
                            }
                        }
                        num10++;
                        numPtr++;
                    }
                    numPtr += num3;
                }
            }
            else
            {
                for (int j = 0; j < height; j++)
                {
                    int num12 = 0;
                    while (num12 < width)
                    {
                        if (((numPtr[2] != r) || (numPtr[1] != g)) || (numPtr[0] != b))
                        {
                            if (num12 < this.minX)
                            {
                                this.minX = num12;
                            }
                            if (num12 > num7)
                            {
                                num7 = num12;
                            }
                            if (j < this.minY)
                            {
                                this.minY = j;
                            }
                            if (j > num8)
                            {
                                num8 = j;
                            }
                        }
                        num12++;
                        numPtr += 3;
                    }
                    numPtr += num3;
                }
            }
            if (((this.minX == width) && (this.minY == height)) && ((num7 == 0) && (num8 == 0)))
            {
                this.minX = this.minY = 0;
            }
            return new Size((num7 - this.minX) + 1, (num8 - this.minY) + 1);
        }

        protected override unsafe void ProcessFilter(UnmanagedImage sourceData, UnmanagedImage destinationData)
        {
            int width = destinationData.Width;
            int height = destinationData.Height;
            int stride = sourceData.Stride;
            int num4 = destinationData.Stride;
            int count = width;
            byte* src = (byte*) sourceData.ImageData.ToPointer();
            byte* dst = (byte*) destinationData.ImageData.ToPointer();
            src += this.minY * stride;
            if (destinationData.PixelFormat == PixelFormat.Format8bppIndexed)
            {
                src += this.minX;
            }
            else
            {
                src += this.minX * 3;
                count *= 3;
            }
            for (int i = 0; i < height; i++)
            {
                SystemTools.CopyUnmanagedMemory(dst, src, count);
                dst += num4;
                src += stride;
            }
        }

        public Color ColorToRemove
        {
            get
            {
                return this.colorToRemove;
            }
            set
            {
                this.colorToRemove = value;
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }
    }
}

