﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing.Imaging;

    public class RotateNearestNeighbor : BaseRotateFilter
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;

        public RotateNearestNeighbor(double angle) : this(angle, false)
        {
        }

        public RotateNearestNeighbor(double angle, bool keepSize) : base(angle, keepSize)
        {
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage sourceData, UnmanagedImage destinationData)
        {
            double num17;
            double num18;
            int num19;
            int num20;
            int width = sourceData.Width;
            int height = sourceData.Height;
            double num3 = ((double) width) / 2.0;
            double num4 = ((double) height) / 2.0;
            int num5 = destinationData.Width;
            int num6 = destinationData.Height;
            double num7 = ((double) num5) / 2.0;
            double num8 = ((double) num6) / 2.0;
            double d = (-base.angle * 3.1415926535897931) / 180.0;
            double num10 = Math.Cos(d);
            double num11 = Math.Sin(d);
            int stride = sourceData.Stride;
            int num13 = destinationData.Stride - ((destinationData.PixelFormat == PixelFormat.Format8bppIndexed) ? num5 : (num5 * 3));
            byte r = this.fillColor.R;
            byte g = this.fillColor.G;
            byte b = this.fillColor.B;
            byte* numPtr = (byte*) sourceData.ImageData.ToPointer();
            byte* numPtr2 = (byte*) destinationData.ImageData.ToPointer();
            if (destinationData.PixelFormat == PixelFormat.Format8bppIndexed)
            {
                num18 = -num8;
                for (int i = 0; i < num6; i++)
                {
                    num17 = -num7;
                    int num22 = 0;
                    while (num22 < num5)
                    {
                        num19 = (int) (((num10 * num17) + (num11 * num18)) + num3);
                        num20 = (int) (((-num11 * num17) + (num10 * num18)) + num4);
                        if (((num19 < 0) || (num20 < 0)) || ((num19 >= width) || (num20 >= height)))
                        {
                            numPtr2[0] = g;
                        }
                        else
                        {
                            numPtr2[0] = numPtr[(num20 * stride) + num19];
                        }
                        num17++;
                        num22++;
                        numPtr2++;
                    }
                    num18++;
                    numPtr2 += num13;
                }
            }
            else
            {
                num18 = -num8;
                for (int j = 0; j < num6; j++)
                {
                    num17 = -num7;
                    int num24 = 0;
                    while (num24 < num5)
                    {
                        num19 = (int) (((num10 * num17) + (num11 * num18)) + num3);
                        num20 = (int) (((-num11 * num17) + (num10 * num18)) + num4);
                        if (((num19 < 0) || (num20 < 0)) || ((num19 >= width) || (num20 >= height)))
                        {
                            numPtr2[2] = r;
                            numPtr2[1] = g;
                            numPtr2[0] = b;
                        }
                        else
                        {
                            byte* numPtr3 = (numPtr + (num20 * stride)) + (num19 * 3);
                            numPtr2[2] = numPtr3[2];
                            numPtr2[1] = numPtr3[1];
                            numPtr2[0] = numPtr3[0];
                        }
                        num17++;
                        num24++;
                        numPtr2 += 3;
                    }
                    num18++;
                    numPtr2 += num13;
                }
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }
    }
}

