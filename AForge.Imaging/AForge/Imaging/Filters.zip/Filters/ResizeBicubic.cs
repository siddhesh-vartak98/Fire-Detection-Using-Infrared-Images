﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing.Imaging;

    public class ResizeBicubic : BaseResizeFilter
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;

        public ResizeBicubic(int newWidth, int newHeight) : base(newWidth, newHeight)
        {
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage sourceData, UnmanagedImage destinationData)
        {
            double num8;
            double num9;
            double num10;
            double num11;
            double num12;
            double num13;
            int num14;
            int num15;
            int num16;
            int num17;
            double num19;
            int width = sourceData.Width;
            int height = sourceData.Height;
            int num3 = (sourceData.PixelFormat == PixelFormat.Format8bppIndexed) ? 1 : 3;
            int stride = sourceData.Stride;
            int num5 = destinationData.Stride - (num3 * base.newWidth);
            double num6 = ((double) width) / ((double) base.newWidth);
            double num7 = ((double) height) / ((double) base.newHeight);
            byte* numPtr = (byte*) sourceData.ImageData.ToPointer();
            byte* numPtr2 = (byte*) destinationData.ImageData.ToPointer();
            int num21 = height - 1;
            int num22 = width - 1;
            if (destinationData.PixelFormat == PixelFormat.Format8bppIndexed)
            {
                for (int i = 0; i < base.newHeight; i++)
                {
                    num9 = (i * num7) - 0.5;
                    num15 = (int) num9;
                    num11 = num9 - num15;
                    int num24 = 0;
                    while (num24 < base.newWidth)
                    {
                        num8 = (num24 * num6) - 0.5;
                        num14 = (int) num8;
                        num10 = num8 - num14;
                        num19 = 0.0;
                        for (int j = -1; j < 3; j++)
                        {
                            num12 = Interpolation.BiCubicKernel(num11 - j);
                            num17 = num15 + j;
                            if (num17 < 0)
                            {
                                num17 = 0;
                            }
                            if (num17 > num21)
                            {
                                num17 = num21;
                            }
                            for (int k = -1; k < 3; k++)
                            {
                                num13 = num12 * Interpolation.BiCubicKernel(k - num10);
                                num16 = num14 + k;
                                if (num16 < 0)
                                {
                                    num16 = 0;
                                }
                                if (num16 > num22)
                                {
                                    num16 = num22;
                                }
                                num19 += num13 * numPtr[(num17 * stride) + num16];
                            }
                        }
                        numPtr2[0] = (byte) Math.Max(0.0, Math.Min(255.0, num19));
                        num24++;
                        numPtr2++;
                    }
                    numPtr2 += num5;
                }
            }
            else
            {
                for (int m = 0; m < base.newHeight; m++)
                {
                    num9 = (m * num7) - 0.5;
                    num15 = (int) num9;
                    num11 = num9 - num15;
                    int num28 = 0;
                    while (num28 < base.newWidth)
                    {
                        double num20;
                        num8 = (num28 * num6) - 0.5;
                        num14 = (int) num8;
                        num10 = num8 - num14;
                        double num18 = num19 = num20 = 0.0;
                        for (int n = -1; n < 3; n++)
                        {
                            num12 = Interpolation.BiCubicKernel(num11 - n);
                            num17 = num15 + n;
                            if (num17 < 0)
                            {
                                num17 = 0;
                            }
                            if (num17 > num21)
                            {
                                num17 = num21;
                            }
                            for (int num30 = -1; num30 < 3; num30++)
                            {
                                num13 = num12 * Interpolation.BiCubicKernel(num30 - num10);
                                num16 = num14 + num30;
                                if (num16 < 0)
                                {
                                    num16 = 0;
                                }
                                if (num16 > num22)
                                {
                                    num16 = num22;
                                }
                                byte* numPtr3 = (numPtr + (num17 * stride)) + (num16 * 3);
                                num18 += num13 * numPtr3[2];
                                num19 += num13 * numPtr3[1];
                                num20 += num13 * numPtr3[0];
                            }
                        }
                        numPtr2[2] = (byte) Math.Max(0.0, Math.Min(255.0, num18));
                        numPtr2[1] = (byte) Math.Max(0.0, Math.Min(255.0, num19));
                        numPtr2[0] = (byte) Math.Max(0.0, Math.Min(255.0, num20));
                        num28++;
                        numPtr2 += 3;
                    }
                    numPtr2 += num5;
                }
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }
    }
}

