﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class ReplaceChannel : BaseInPlacePartialFilter
    {
        private short channel;
        private Bitmap channelImage;
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;
        private UnmanagedImage unmanagedChannelImage;

        private ReplaceChannel()
        {
            this.channel = 2;
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
            this.formatTranslations[PixelFormat.Format32bppRgb] = PixelFormat.Format32bppRgb;
            this.formatTranslations[PixelFormat.Format32bppArgb] = PixelFormat.Format32bppArgb;
            this.formatTranslations[PixelFormat.Format48bppRgb] = PixelFormat.Format16bppGrayScale;
            this.formatTranslations[PixelFormat.Format64bppArgb] = PixelFormat.Format16bppGrayScale;
        }

        public ReplaceChannel(short channel, UnmanagedImage channelImage) : this()
        {
            this.Channel = channel;
            this.UnmanagedChannelImage = channelImage;
        }

        public ReplaceChannel(short channel, Bitmap channelImage) : this()
        {
            this.Channel = channel;
            this.ChannelImage = channelImage;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage image, Rectangle rect)
        {
            byte* imageData;
            int num = Image.GetPixelFormatSize(image.PixelFormat) / 8;
            if (((this.channel == 3) && (num != 4)) && (num != 8))
            {
                throw new InvalidImagePropertiesException("Can not replace alpha channel of none ARGB image.");
            }
            int width = image.Width;
            int height = image.Height;
            int left = rect.Left;
            int top = rect.Top;
            int num6 = left + rect.Width;
            int num7 = top + rect.Height;
            int num8 = image.Stride - (rect.Width * num);
            BitmapData bitmapdata = null;
            int stride = 0;
            PixelFormat pixelFormat = PixelFormat.Format16bppGrayScale;
            if (this.channelImage != null)
            {
                if ((width != this.channelImage.Width) || (height != this.channelImage.Height))
                {
                    throw new InvalidImagePropertiesException("Channel image size does not match source image size.");
                }
                bitmapdata = this.channelImage.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadOnly, this.channelImage.PixelFormat);
                imageData = (byte*) bitmapdata.Scan0.ToPointer();
                stride = bitmapdata.Stride;
                pixelFormat = bitmapdata.PixelFormat;
            }
            else
            {
                if ((width != this.unmanagedChannelImage.Width) || (height != this.unmanagedChannelImage.Height))
                {
                    throw new InvalidImagePropertiesException("Channel image size does not match source image size.");
                }
                imageData = (byte*) this.unmanagedChannelImage.ImageData;
                stride = this.unmanagedChannelImage.Stride;
                pixelFormat = this.unmanagedChannelImage.PixelFormat;
            }
            if (num <= 4)
            {
                if (pixelFormat != PixelFormat.Format8bppIndexed)
                {
                    throw new InvalidImagePropertiesException("Channel image's format does not correspond to format of the source image.");
                }
                int num10 = bitmapdata.Stride - rect.Width;
                byte* numPtr2 = (byte*) (image.ImageData.ToPointer() + ((top * image.Stride) + (left * num)));
                imageData += (top * stride) + left;
                for (int i = top; i < num7; i++)
                {
                    int num12 = left;
                    while (num12 < num6)
                    {
                        numPtr2[this.channel] = imageData[0];
                        num12++;
                        numPtr2 += num;
                        imageData++;
                    }
                    numPtr2 += num8;
                    imageData += num10;
                }
            }
            else
            {
                if (pixelFormat != PixelFormat.Format16bppGrayScale)
                {
                    throw new InvalidImagePropertiesException("Channel image's format does not correspond to format of the source image.");
                }
                int num13 = image.Stride;
                byte* numPtr3 = (byte*) (image.ImageData.ToPointer() + (left * num));
                imageData += left * 2;
                num /= 2;
                for (int j = top; j < num7; j++)
                {
                    ushort* numPtr4 = (ushort*) (numPtr3 + (j * num13));
                    ushort* numPtr5 = (ushort*) (imageData + (j * stride));
                    int num15 = left;
                    while (num15 < num6)
                    {
                        numPtr4[this.channel] = numPtr5[0];
                        num15++;
                        numPtr4 += num;
                        numPtr5++;
                    }
                }
            }
            if (bitmapdata != null)
            {
                this.channelImage.UnlockBits(bitmapdata);
            }
        }

        public short Channel
        {
            get
            {
                return this.channel;
            }
            set
            {
                if (((value != 2) && (value != 1)) && ((value != 0) && (value != 3)))
                {
                    throw new ArgumentException("Invalid channel is specified.");
                }
                this.channel = value;
            }
        }

        public Bitmap ChannelImage
        {
            get
            {
                return this.channelImage;
            }
            set
            {
                if (value == null)
                {
                    throw new NullReferenceException("Channel image was not specified.");
                }
                if ((value.PixelFormat != PixelFormat.Format8bppIndexed) && (value.PixelFormat != PixelFormat.Format16bppGrayScale))
                {
                    throw new InvalidImagePropertiesException("Channel image should be 8 bpp indexed or 16 bpp grayscale image.");
                }
                this.channelImage = value;
                this.unmanagedChannelImage = null;
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public UnmanagedImage UnmanagedChannelImage
        {
            get
            {
                return this.unmanagedChannelImage;
            }
            set
            {
                if (value == null)
                {
                    throw new NullReferenceException("Channel image was not specified.");
                }
                if ((value.PixelFormat != PixelFormat.Format8bppIndexed) && (value.PixelFormat != PixelFormat.Format16bppGrayScale))
                {
                    throw new InvalidImagePropertiesException("Channel image should be 8 bpp indexed or 16 bpp grayscale image.");
                }
                this.channelImage = null;
                this.unmanagedChannelImage = value;
            }
        }
    }
}

