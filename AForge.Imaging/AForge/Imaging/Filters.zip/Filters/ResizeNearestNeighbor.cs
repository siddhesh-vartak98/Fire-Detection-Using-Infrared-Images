﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class ResizeNearestNeighbor : BaseResizeFilter
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;

        public ResizeNearestNeighbor(int newWidth, int newHeight) : base(newWidth, newHeight)
        {
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
            this.formatTranslations[PixelFormat.Format32bppRgb] = PixelFormat.Format32bppRgb;
            this.formatTranslations[PixelFormat.Format32bppArgb] = PixelFormat.Format32bppArgb;
            this.formatTranslations[PixelFormat.Format16bppGrayScale] = PixelFormat.Format16bppGrayScale;
            this.formatTranslations[PixelFormat.Format48bppRgb] = PixelFormat.Format48bppRgb;
            this.formatTranslations[PixelFormat.Format64bppArgb] = PixelFormat.Format64bppArgb;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage sourceData, UnmanagedImage destinationData)
        {
            int width = sourceData.Width;
            int height = sourceData.Height;
            int num3 = Image.GetPixelFormatSize(sourceData.PixelFormat) / 8;
            int stride = sourceData.Stride;
            int num5 = destinationData.Stride;
            double num6 = ((double) width) / ((double) base.newWidth);
            double num7 = ((double) height) / ((double) base.newHeight);
            byte* numPtr = (byte*) sourceData.ImageData.ToPointer();
            byte* numPtr2 = (byte*) destinationData.ImageData.ToPointer();
            for (int i = 0; i < base.newHeight; i++)
            {
                byte* numPtr3 = numPtr2 + (num5 * i);
                byte* numPtr4 = numPtr + (stride * ((int) (i * num7)));
                for (int j = 0; j < base.newWidth; j++)
                {
                    byte* numPtr5 = numPtr4 + (num3 * ((int) (j * num6)));
                    int num10 = 0;
                    while (num10 < num3)
                    {
                        numPtr3[0] = numPtr5[0];
                        num10++;
                        numPtr3++;
                        numPtr5++;
                    }
                }
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }
    }
}

