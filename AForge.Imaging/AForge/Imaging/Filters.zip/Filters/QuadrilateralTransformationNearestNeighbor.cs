﻿namespace AForge.Imaging.Filters
{
    using AForge;
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;

    [Obsolete("The class is deprecated and SimpleQuadrilateralTransformation should be used instead")]
    public class QuadrilateralTransformationNearestNeighbor : BaseTransformationFilter
    {
        private SimpleQuadrilateralTransformation baseFilter;

        public QuadrilateralTransformationNearestNeighbor(List<IntPoint> sourceCorners)
        {
            this.baseFilter = new SimpleQuadrilateralTransformation(sourceCorners);
            this.baseFilter.UseInterpolation = false;
        }

        public QuadrilateralTransformationNearestNeighbor(List<IntPoint> sourceCorners, int newWidth, int newHeight)
        {
            this.baseFilter = new SimpleQuadrilateralTransformation(sourceCorners, newWidth, newHeight);
            this.baseFilter.UseInterpolation = false;
        }

        protected override Size CalculateNewImageSize(UnmanagedImage sourceData)
        {
            foreach (IntPoint point in this.baseFilter.SourceQuadrilateral)
            {
                if (((point.X < 0) || (point.Y < 0)) || ((point.X >= sourceData.Width) || (point.Y >= sourceData.Height)))
                {
                    throw new ArgumentException("The specified quadrilateral's corners are outside of the given image.");
                }
            }
            return new Size(this.baseFilter.NewWidth, this.baseFilter.NewHeight);
        }

        protected override void ProcessFilter(UnmanagedImage sourceData, UnmanagedImage destinationData)
        {
            this.baseFilter.Apply(sourceData, destinationData);
        }

        public bool AutomaticSizeCalculaton
        {
            get
            {
                return this.baseFilter.AutomaticSizeCalculaton;
            }
            set
            {
                this.baseFilter.AutomaticSizeCalculaton = value;
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.baseFilter.FormatTranslations;
            }
        }

        public int NewHeight
        {
            get
            {
                return this.baseFilter.NewHeight;
            }
            set
            {
                this.baseFilter.NewHeight = value;
            }
        }

        public int NewWidth
        {
            get
            {
                return this.baseFilter.NewWidth;
            }
            set
            {
                this.baseFilter.NewWidth = value;
            }
        }

        public List<IntPoint> SourceCorners
        {
            get
            {
                return this.baseFilter.SourceQuadrilateral;
            }
            set
            {
                this.baseFilter.SourceQuadrilateral = value;
            }
        }
    }
}

