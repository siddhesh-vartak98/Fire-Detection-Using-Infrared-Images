﻿namespace AForge.Imaging.Filters
{
    using AForge;
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class PointedMeanFloodFill : BaseInPlacePartialFilter
    {
        private bool[,] checkedPixels;
        private Dictionary<PixelFormat, PixelFormat> formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
        private byte maxB;
        private byte maxG;
        private byte maxR;
        private int meanB;
        private int meanG;
        private int meanR;
        private byte minB;
        private byte minG;
        private byte minR;
        private int pixelsCount;
        private int scan0;
        private IntPoint startingPoint = new IntPoint(0, 0);
        private int startX;
        private int startY;
        private int stopX;
        private int stopY;
        private int stride;
        private Color tolerance = Color.FromArgb(0x10, 0x10, 0x10);

        public PointedMeanFloodFill()
        {
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
        }

        private bool CheckGrayPixel(byte pixel)
        {
            return ((pixel >= this.minG) && (pixel <= this.maxG));
        }

        private unsafe bool CheckRGBPixel(byte* pixel)
        {
            return (((((pixel[2] >= this.minR) && (pixel[2] <= this.maxR)) && ((pixel[1] >= this.minG) && (pixel[1] <= this.maxG))) && (pixel[0] >= this.minB)) && (pixel[0] <= this.maxB));
        }

        private int CoordsToPointerGray(int x, int y)
        {
            return ((this.scan0 + (this.stride * y)) + x);
        }

        private int CoordsToPointerRGB(int x, int y)
        {
            return ((this.scan0 + (this.stride * y)) + (x * 3));
        }

        private unsafe void LinearFloodFill4Gray(int x, int y)
        {
            byte* numPtr = (byte*) this.CoordsToPointerGray(x, y);
            int num = x;
            byte* numPtr2 = numPtr;
            do
            {
                this.meanG += numPtr2[0];
                this.pixelsCount++;
                this.checkedPixels[y, num] = true;
                num--;
                numPtr2--;
            }
            while (((num >= this.startX) && !this.checkedPixels[y, num]) && this.CheckGrayPixel(numPtr2[0]));
            num++;
            int num2 = x + 1;
            for (numPtr2 = numPtr + 1; ((num2 <= this.stopX) && !this.checkedPixels[y, num2]) && this.CheckGrayPixel(numPtr2[0]); numPtr2++)
            {
                this.meanG += numPtr2[0];
                this.pixelsCount++;
                this.checkedPixels[y, num2] = true;
                num2++;
            }
            num2--;
            numPtr2 = (byte*) this.CoordsToPointerGray(num, y);
            int num3 = num;
            while (num3 <= num2)
            {
                if (((y > this.startY) && !this.checkedPixels[y - 1, num3]) && this.CheckGrayPixel(*(numPtr2 - this.stride)))
                {
                    this.LinearFloodFill4Gray(num3, y - 1);
                }
                if (((y < this.stopY) && !this.checkedPixels[y + 1, num3]) && this.CheckGrayPixel(numPtr2[this.stride]))
                {
                    this.LinearFloodFill4Gray(num3, y + 1);
                }
                num3++;
                numPtr2++;
            }
        }

        private unsafe void LinearFloodFill4RGB(int x, int y)
        {
            byte* numPtr = (byte*) this.CoordsToPointerRGB(x, y);
            int num = x;
            byte* pixel = numPtr;
            do
            {
                this.meanR += pixel[2];
                this.meanG += pixel[1];
                this.meanB += pixel[0];
                this.pixelsCount++;
                this.checkedPixels[y, num] = true;
                num--;
                pixel -= 3;
            }
            while (((num >= this.startX) && !this.checkedPixels[y, num]) && this.CheckRGBPixel(pixel));
            num++;
            int num2 = x + 1;
            for (pixel = numPtr + 3; ((num2 <= this.stopX) && !this.checkedPixels[y, num2]) && this.CheckRGBPixel(pixel); pixel += 3)
            {
                this.meanR += pixel[2];
                this.meanG += pixel[1];
                this.meanB += pixel[0];
                this.pixelsCount++;
                this.checkedPixels[y, num2] = true;
                num2++;
            }
            num2--;
            pixel = (byte*) this.CoordsToPointerRGB(num, y);
            int num3 = num;
            while (num3 <= num2)
            {
                if (((y > this.startY) && !this.checkedPixels[y - 1, num3]) && this.CheckRGBPixel(pixel - this.stride))
                {
                    this.LinearFloodFill4RGB(num3, y - 1);
                }
                if (((y < this.stopY) && !this.checkedPixels[y + 1, num3]) && this.CheckRGBPixel(pixel + this.stride))
                {
                    this.LinearFloodFill4RGB(num3, y + 1);
                }
                num3++;
                pixel += 3;
            }
        }

        protected override unsafe void ProcessFilter(UnmanagedImage image, Rectangle rect)
        {
            if (rect.Contains(this.startingPoint.X, this.startingPoint.Y) && (this.tolerance != Color.Black))
            {
                this.startX = rect.Left;
                this.startY = rect.Top;
                this.stopX = rect.Right - 1;
                this.stopY = rect.Bottom - 1;
                this.scan0 = image.ImageData.ToInt32();
                this.stride = image.Stride;
                this.checkedPixels = new bool[image.Height, image.Width];
                this.pixelsCount = this.meanR = this.meanG = this.meanB = 0;
                if (image.PixelFormat == PixelFormat.Format8bppIndexed)
                {
                    byte num = *((byte*) this.CoordsToPointerGray(this.startingPoint.X, this.startingPoint.Y));
                    this.minG = (byte) Math.Max(0, num - this.tolerance.G);
                    this.maxG = (byte) Math.Min(0xff, num + this.tolerance.G);
                    this.LinearFloodFill4Gray(this.startingPoint.X, this.startingPoint.Y);
                    this.meanG /= this.pixelsCount;
                    byte meanG = (byte) this.meanG;
                    byte* numPtr = (byte*) (image.ImageData.ToPointer() + ((this.startY * this.stride) + this.startX));
                    int num3 = this.stride - rect.Width;
                    for (int i = this.startY; i <= this.stopY; i++)
                    {
                        int startX = this.startX;
                        while (startX <= this.stopX)
                        {
                            if (this.checkedPixels[i, startX])
                            {
                                numPtr[0] = meanG;
                            }
                            startX++;
                            numPtr++;
                        }
                        numPtr += num3;
                    }
                }
                else
                {
                    byte* numPtr2 = (byte*) this.CoordsToPointerRGB(this.startingPoint.X, this.startingPoint.Y);
                    this.minR = (byte) Math.Max(0, numPtr2[2] - this.tolerance.R);
                    this.maxR = (byte) Math.Min(0xff, numPtr2[2] + this.tolerance.R);
                    this.minG = (byte) Math.Max(0, numPtr2[1] - this.tolerance.G);
                    this.maxG = (byte) Math.Min(0xff, numPtr2[1] + this.tolerance.G);
                    this.minB = (byte) Math.Max(0, numPtr2[0] - this.tolerance.B);
                    this.maxB = (byte) Math.Min(0xff, numPtr2[0] + this.tolerance.B);
                    this.LinearFloodFill4RGB(this.startingPoint.X, this.startingPoint.Y);
                    this.meanR /= this.pixelsCount;
                    this.meanG /= this.pixelsCount;
                    this.meanB /= this.pixelsCount;
                    byte meanR = (byte) this.meanR;
                    byte num7 = (byte) this.meanG;
                    byte meanB = (byte) this.meanB;
                    byte* numPtr3 = (byte*) (image.ImageData.ToPointer() + ((this.startY * this.stride) + (this.startX * 3)));
                    int num9 = this.stride - (rect.Width * 3);
                    for (int j = this.startY; j <= this.stopY; j++)
                    {
                        int num11 = this.startX;
                        while (num11 <= this.stopX)
                        {
                            if (this.checkedPixels[j, num11])
                            {
                                numPtr3[2] = meanR;
                                numPtr3[1] = num7;
                                numPtr3[0] = meanB;
                            }
                            num11++;
                            numPtr3 += 3;
                        }
                        numPtr3 += num9;
                    }
                }
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public IntPoint StartingPoint
        {
            get
            {
                return this.startingPoint;
            }
            set
            {
                this.startingPoint = value;
            }
        }

        public Color Tolerance
        {
            get
            {
                return this.tolerance;
            }
            set
            {
                this.tolerance = value;
            }
        }
    }
}

