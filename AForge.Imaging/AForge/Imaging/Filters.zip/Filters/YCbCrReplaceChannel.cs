﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class YCbCrReplaceChannel : BaseInPlacePartialFilter
    {
        private short channel;
        private Bitmap channelImage;
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;
        private UnmanagedImage unmanagedChannelImage;

        private YCbCrReplaceChannel()
        {
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
            this.formatTranslations[PixelFormat.Format32bppRgb] = PixelFormat.Format32bppRgb;
            this.formatTranslations[PixelFormat.Format32bppArgb] = PixelFormat.Format32bppArgb;
        }

        public YCbCrReplaceChannel(short channel, UnmanagedImage channelImage) : this()
        {
            this.Channel = channel;
            this.UnmanagedChannelImage = channelImage;
        }

        public YCbCrReplaceChannel(short channel, Bitmap channelImage) : this()
        {
            this.Channel = channel;
            this.ChannelImage = channelImage;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage image, Rectangle rect)
        {
            byte* imageData;
            int num = Image.GetPixelFormatSize(image.PixelFormat) / 8;
            int width = image.Width;
            int height = image.Height;
            int left = rect.Left;
            int top = rect.Top;
            int num6 = left + rect.Width;
            int num7 = top + rect.Height;
            int num8 = image.Stride - (rect.Width * num);
            BitmapData bitmapdata = null;
            int stride = 0;
            if (this.channelImage != null)
            {
                if ((width != this.channelImage.Width) || (height != this.channelImage.Height))
                {
                    throw new InvalidImagePropertiesException("Channel image size does not match source image size.");
                }
                bitmapdata = this.channelImage.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadOnly, PixelFormat.Format8bppIndexed);
                imageData = (byte*) bitmapdata.Scan0.ToPointer();
                stride = bitmapdata.Stride;
            }
            else
            {
                if ((width != this.unmanagedChannelImage.Width) || (height != this.unmanagedChannelImage.Height))
                {
                    throw new InvalidImagePropertiesException("Channel image size does not match source image size.");
                }
                imageData = (byte*) this.unmanagedChannelImage.ImageData;
                stride = this.unmanagedChannelImage.Stride;
            }
            int num10 = stride - rect.Width;
            RGB rgb = new RGB();
            YCbCr ycbcr = new YCbCr();
            byte* numPtr2 = (byte*) (image.ImageData.ToPointer() + ((top * image.Stride) + (left * num)));
            imageData += (top * stride) + left;
            for (int i = top; i < num7; i++)
            {
                int num12 = left;
                while (num12 < num6)
                {
                    rgb.Red = numPtr2[2];
                    rgb.Green = numPtr2[1];
                    rgb.Blue = numPtr2[0];
                    YCbCr.FromRGB(rgb, ycbcr);
                    switch (this.channel)
                    {
                        case 0:
                            ycbcr.Y = ((double) imageData[0]) / 255.0;
                            break;

                        case 1:
                            ycbcr.Cb = (((double) imageData[0]) / 255.0) - 0.5;
                            break;

                        case 2:
                            ycbcr.Cr = (((double) imageData[0]) / 255.0) - 0.5;
                            break;
                    }
                    YCbCr.ToRGB(ycbcr, rgb);
                    numPtr2[2] = rgb.Red;
                    numPtr2[1] = rgb.Green;
                    numPtr2[0] = rgb.Blue;
                    num12++;
                    numPtr2 += num;
                    imageData++;
                }
                numPtr2 += num8;
                imageData += num10;
            }
            if (bitmapdata != null)
            {
                this.channelImage.UnlockBits(bitmapdata);
            }
        }

        public short Channel
        {
            get
            {
                return this.channel;
            }
            set
            {
                if (((value != 0) && (value != 1)) && (value != 2))
                {
                    throw new ArgumentException("Invalid YCbCr channel was specified.");
                }
                this.channel = value;
            }
        }

        public Bitmap ChannelImage
        {
            get
            {
                return this.channelImage;
            }
            set
            {
                if (value == null)
                {
                    throw new NullReferenceException("Channel image was not specified.");
                }
                if (value.PixelFormat != PixelFormat.Format8bppIndexed)
                {
                    throw new InvalidImagePropertiesException("Channel image should be 8bpp indexed image (grayscale).");
                }
                this.channelImage = value;
                this.unmanagedChannelImage = null;
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public UnmanagedImage UnmanagedChannelImage
        {
            get
            {
                return this.unmanagedChannelImage;
            }
            set
            {
                if (value == null)
                {
                    throw new NullReferenceException("Channel image was not specified.");
                }
                if (value.PixelFormat != PixelFormat.Format8bppIndexed)
                {
                    throw new InvalidImagePropertiesException("Channel image should be 8bpp indexed image (grayscale).");
                }
                this.channelImage = null;
                this.unmanagedChannelImage = value;
            }
        }
    }
}

