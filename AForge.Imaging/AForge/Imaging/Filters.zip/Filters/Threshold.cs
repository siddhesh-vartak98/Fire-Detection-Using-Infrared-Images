﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class Threshold : BaseInPlacePartialFilter
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;
        protected int threshold;

        public Threshold()
        {
            this.threshold = 0x80;
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format16bppGrayScale] = PixelFormat.Format16bppGrayScale;
        }

        public Threshold(int threshold) : this()
        {
            this.threshold = threshold;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage image, Rectangle rect)
        {
            int left = rect.Left;
            int top = rect.Top;
            int num3 = left + rect.Width;
            int num4 = top + rect.Height;
            if (image.PixelFormat == PixelFormat.Format8bppIndexed)
            {
                int num5 = image.Stride - rect.Width;
                byte* numPtr = (byte*) (image.ImageData.ToPointer() + ((top * image.Stride) + left));
                for (int i = top; i < num4; i++)
                {
                    int num7 = left;
                    while (num7 < num3)
                    {
                        numPtr[0] = (numPtr[0] >= this.threshold) ? ((byte) 0xff) : ((byte) 0);
                        num7++;
                        numPtr++;
                    }
                    numPtr += num5;
                }
            }
            else
            {
                byte* numPtr2 = (byte*) (image.ImageData.ToPointer() + (left * 2));
                int stride = image.Stride;
                for (int j = top; j < num4; j++)
                {
                    ushort* numPtr3 = (ushort*) (numPtr2 + (stride * j));
                    int num10 = left;
                    while (num10 < num3)
                    {
                        numPtr3[0] = (numPtr3[0] >= this.threshold) ? ((ushort) 0xffff) : ((ushort) 0);
                        num10++;
                        numPtr3++;
                    }
                }
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public int ThresholdValue
        {
            get
            {
                return this.threshold;
            }
            set
            {
                this.threshold = value;
            }
        }
    }
}

