﻿namespace AForge.Imaging.Filters
{
    using AForge;
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class YCbCrLinear : BaseInPlacePartialFilter
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
        private DoubleRange inCb = new DoubleRange(-0.5, 0.5);
        private DoubleRange inCr = new DoubleRange(-0.5, 0.5);
        private DoubleRange inY = new DoubleRange(0.0, 1.0);
        private DoubleRange outCb = new DoubleRange(-0.5, 0.5);
        private DoubleRange outCr = new DoubleRange(-0.5, 0.5);
        private DoubleRange outY = new DoubleRange(0.0, 1.0);

        public YCbCrLinear()
        {
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
            this.formatTranslations[PixelFormat.Format32bppRgb] = PixelFormat.Format32bppRgb;
            this.formatTranslations[PixelFormat.Format32bppArgb] = PixelFormat.Format32bppArgb;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage image, Rectangle rect)
        {
            int num = Image.GetPixelFormatSize(image.PixelFormat) / 8;
            int left = rect.Left;
            int top = rect.Top;
            int num4 = left + rect.Width;
            int num5 = top + rect.Height;
            int num6 = image.Stride - (rect.Width * num);
            RGB rgb = new RGB();
            YCbCr ycbcr = new YCbCr();
            double num7 = 0.0;
            double num8 = 0.0;
            double num9 = 0.0;
            double num10 = 0.0;
            double num11 = 0.0;
            double num12 = 0.0;
            if (this.inY.Max != this.inY.Min)
            {
                num7 = (this.outY.Max - this.outY.Min) / (this.inY.Max - this.inY.Min);
                num8 = this.outY.Min - (num7 * this.inY.Min);
            }
            if (this.inCb.Max != this.inCb.Min)
            {
                num9 = (this.outCb.Max - this.outCb.Min) / (this.inCb.Max - this.inCb.Min);
                num10 = this.outCb.Min - (num9 * this.inCb.Min);
            }
            if (this.inCr.Max != this.inCr.Min)
            {
                num11 = (this.outCr.Max - this.outCr.Min) / (this.inCr.Max - this.inCr.Min);
                num12 = this.outCr.Min - (num11 * this.inCr.Min);
            }
            byte* numPtr = (byte*) (image.ImageData.ToPointer() + ((top * image.Stride) + (left * num)));
            for (int i = top; i < num5; i++)
            {
                int num14 = left;
                while (num14 < num4)
                {
                    rgb.Red = numPtr[2];
                    rgb.Green = numPtr[1];
                    rgb.Blue = numPtr[0];
                    YCbCr.FromRGB(rgb, ycbcr);
                    if (ycbcr.Y >= this.inY.Max)
                    {
                        ycbcr.Y = this.outY.Max;
                    }
                    else if (ycbcr.Y <= this.inY.Min)
                    {
                        ycbcr.Y = this.outY.Min;
                    }
                    else
                    {
                        ycbcr.Y = (num7 * ycbcr.Y) + num8;
                    }
                    if (ycbcr.Cb >= this.inCb.Max)
                    {
                        ycbcr.Cb = this.outCb.Max;
                    }
                    else if (ycbcr.Cb <= this.inCb.Min)
                    {
                        ycbcr.Cb = this.outCb.Min;
                    }
                    else
                    {
                        ycbcr.Cb = (num9 * ycbcr.Cb) + num10;
                    }
                    if (ycbcr.Cr >= this.inCr.Max)
                    {
                        ycbcr.Cr = this.outCr.Max;
                    }
                    else if (ycbcr.Cr <= this.inCr.Min)
                    {
                        ycbcr.Cr = this.outCr.Min;
                    }
                    else
                    {
                        ycbcr.Cr = (num11 * ycbcr.Cr) + num12;
                    }
                    YCbCr.ToRGB(ycbcr, rgb);
                    numPtr[2] = rgb.Red;
                    numPtr[1] = rgb.Green;
                    numPtr[0] = rgb.Blue;
                    num14++;
                    numPtr += num;
                }
                numPtr += num6;
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public DoubleRange InCb
        {
            get
            {
                return this.inCb;
            }
            set
            {
                this.inCb = value;
            }
        }

        public DoubleRange InCr
        {
            get
            {
                return this.inCr;
            }
            set
            {
                this.inCr = value;
            }
        }

        public DoubleRange InY
        {
            get
            {
                return this.inY;
            }
            set
            {
                this.inY = value;
            }
        }

        public DoubleRange OutCb
        {
            get
            {
                return this.outCb;
            }
            set
            {
                this.outCb = value;
            }
        }

        public DoubleRange OutCr
        {
            get
            {
                return this.outCr;
            }
            set
            {
                this.outCr = value;
            }
        }

        public DoubleRange OutY
        {
            get
            {
                return this.outY;
            }
            set
            {
                this.outY = value;
            }
        }
    }
}

