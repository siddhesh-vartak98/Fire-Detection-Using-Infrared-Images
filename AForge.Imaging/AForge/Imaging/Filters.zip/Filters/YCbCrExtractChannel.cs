﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class YCbCrExtractChannel : BaseFilter
    {
        private short channel;
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;

        public YCbCrExtractChannel()
        {
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format32bppRgb] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format32bppArgb] = PixelFormat.Format8bppIndexed;
        }

        public YCbCrExtractChannel(short channel) : this()
        {
            this.Channel = channel;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage sourceData, UnmanagedImage destinationData)
        {
            int num = Image.GetPixelFormatSize(sourceData.PixelFormat) / 8;
            int width = sourceData.Width;
            int height = sourceData.Height;
            int num4 = sourceData.Stride - (width * num);
            int num5 = destinationData.Stride - width;
            RGB rgb = new RGB();
            YCbCr ycbcr = new YCbCr();
            byte* numPtr = (byte*) sourceData.ImageData.ToPointer();
            byte* numPtr2 = (byte*) destinationData.ImageData.ToPointer();
            byte num6 = 0;
            for (int i = 0; i < height; i++)
            {
                int num8 = 0;
                while (num8 < width)
                {
                    rgb.Red = numPtr[2];
                    rgb.Green = numPtr[1];
                    rgb.Blue = numPtr[0];
                    YCbCr.FromRGB(rgb, ycbcr);
                    switch (this.channel)
                    {
                        case 0:
                            num6 = (byte) (ycbcr.Y * 255.0);
                            break;

                        case 1:
                            num6 = (byte) ((ycbcr.Cb + 0.5) * 255.0);
                            break;

                        case 2:
                            num6 = (byte) ((ycbcr.Cr + 0.5) * 255.0);
                            break;
                    }
                    numPtr2[0] = num6;
                    num8++;
                    numPtr += num;
                    numPtr2++;
                }
                numPtr += num4;
                numPtr2 += num5;
            }
        }

        public short Channel
        {
            get
            {
                return this.channel;
            }
            set
            {
                if (((value != 0) && (value != 1)) && (value != 2))
                {
                    throw new ArgumentException("Invalid channel was specified.");
                }
                this.channel = value;
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }
    }
}

