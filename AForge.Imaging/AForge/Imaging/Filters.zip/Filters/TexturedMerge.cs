﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using AForge.Imaging.Textures;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class TexturedMerge : BaseInPlaceFilter2
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;
        private float[,] texture;
        private ITextureGenerator textureGenerator;

        private TexturedMerge()
        {
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
        }

        public TexturedMerge(float[,] texture) : this()
        {
            this.texture = texture;
        }

        public TexturedMerge(ITextureGenerator generator) : this()
        {
            this.textureGenerator = generator;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage image, UnmanagedImage overlay)
        {
            int width = image.Width;
            int height = image.Height;
            int num3 = width;
            int num4 = height;
            if (this.textureGenerator != null)
            {
                this.texture = this.textureGenerator.Generate(width, height);
            }
            else
            {
                num3 = Math.Min(width, this.texture.GetLength(1));
                num4 = Math.Min(height, this.texture.GetLength(0));
            }
            int num5 = Image.GetPixelFormatSize(image.PixelFormat) / 8;
            int num6 = image.Stride - (num3 * num5);
            int num7 = overlay.Stride - (num3 * num5);
            byte* numPtr = (byte*) image.ImageData.ToPointer();
            byte* numPtr2 = (byte*) overlay.ImageData.ToPointer();
            for (int i = 0; i < num4; i++)
            {
                for (int j = 0; j < num3; j++)
                {
                    double num10 = this.texture[i, j];
                    double num11 = 1.0 - num10;
                    int num12 = 0;
                    while (num12 < num5)
                    {
                        numPtr[0] = (byte) Math.Min((double) 255.0, (double) ((numPtr[0] * num10) + (numPtr2[0] * num11)));
                        num12++;
                        numPtr++;
                        numPtr2++;
                    }
                }
                numPtr += num6;
                numPtr2 += num7;
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public float[,] Texture
        {
            get
            {
                return this.texture;
            }
            set
            {
                this.texture = value;
            }
        }

        public ITextureGenerator TextureGenerator
        {
            get
            {
                return this.textureGenerator;
            }
            set
            {
                this.textureGenerator = value;
            }
        }
    }
}

