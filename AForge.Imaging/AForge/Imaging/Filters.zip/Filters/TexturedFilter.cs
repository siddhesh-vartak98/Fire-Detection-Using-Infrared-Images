﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using AForge.Imaging.Textures;
    using System;
    using System.Collections.Generic;
    using System.Drawing.Imaging;

    public class TexturedFilter : BaseFilter
    {
        private IFilter filter1;
        private IFilter filter2;
        private double filterLevel;
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;
        private double preserveLevel;
        private float[,] texture;
        private ITextureGenerator textureGenerator;

        private TexturedFilter()
        {
            this.filterLevel = 1.0;
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
        }

        public TexturedFilter(float[,] texture, IFilter filter1) : this()
        {
            this.texture = texture;
            this.filter1 = filter1;
        }

        public TexturedFilter(ITextureGenerator generator, IFilter filter1) : this()
        {
            this.textureGenerator = generator;
            this.filter1 = filter1;
        }

        public TexturedFilter(float[,] texture, IFilter filter1, IFilter filter2) : this()
        {
            this.texture = texture;
            this.filter1 = filter1;
            this.filter2 = filter2;
        }

        public TexturedFilter(ITextureGenerator generator, IFilter filter1, IFilter filter2) : this()
        {
            this.textureGenerator = generator;
            this.filter1 = filter1;
            this.filter2 = filter2;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage sourceData, UnmanagedImage destinationData)
        {
            int width = sourceData.Width;
            int height = sourceData.Height;
            if (this.textureGenerator != null)
            {
                this.texture = this.textureGenerator.Generate(width, height);
            }
            else if ((this.texture.GetLength(0) != height) || (this.texture.GetLength(1) != width))
            {
                throw new InvalidImagePropertiesException("Texture size does not match image size.");
            }
            UnmanagedImage image = this.filter1.Apply(sourceData);
            if ((width != image.Width) || (height != image.Height))
            {
                image.Dispose();
                throw new ApplicationException("Filters should not change image dimension.");
            }
            if (image.PixelFormat == PixelFormat.Format8bppIndexed)
            {
                UnmanagedImage image2 = new GrayscaleToRGB().Apply(image);
                image.Dispose();
                image = image2;
            }
            UnmanagedImage image3 = null;
            if (this.filter2 != null)
            {
                image3 = this.filter2.Apply(sourceData);
                if ((width != image3.Width) || (height != image3.Height))
                {
                    image.Dispose();
                    image3.Dispose();
                    throw new ApplicationException("Filters should not change image dimension.");
                }
                if (image3.PixelFormat == PixelFormat.Format8bppIndexed)
                {
                    UnmanagedImage image4 = new GrayscaleToRGB().Apply(image3);
                    image3.Dispose();
                    image3 = image4;
                }
            }
            if (image3 == null)
            {
                image3 = sourceData;
            }
            byte* numPtr = (byte*) destinationData.ImageData.ToPointer();
            byte* numPtr2 = (byte*) image.ImageData.ToPointer();
            byte* numPtr3 = (byte*) image3.ImageData.ToPointer();
            int num3 = destinationData.Stride - (3 * width);
            int num4 = image.Stride - (3 * width);
            int num5 = image3.Stride - (3 * width);
            if (this.preserveLevel != 0.0)
            {
                for (int i = 0; i < height; i++)
                {
                    for (int j = 0; j < width; j++)
                    {
                        double num8 = this.texture[i, j];
                        double num9 = 1.0 - num8;
                        int num10 = 0;
                        while (num10 < 3)
                        {
                            numPtr[0] = (byte) Math.Min((double) 255.0, (double) ((this.filterLevel * ((num8 * numPtr2[0]) + (num9 * numPtr3[0]))) + (this.preserveLevel * numPtr3[0])));
                            num10++;
                            numPtr2++;
                            numPtr3++;
                            numPtr++;
                        }
                    }
                    numPtr2 += num4;
                    numPtr3 += num5;
                    numPtr += num3;
                }
            }
            else
            {
                for (int k = 0; k < height; k++)
                {
                    for (int m = 0; m < width; m++)
                    {
                        double num13 = this.texture[k, m];
                        double num14 = 1.0 - num13;
                        int num15 = 0;
                        while (num15 < 3)
                        {
                            numPtr[0] = (byte) Math.Min((double) 255.0, (double) ((num13 * numPtr2[0]) + (num14 * numPtr3[0])));
                            num15++;
                            numPtr2++;
                            numPtr3++;
                            numPtr++;
                        }
                    }
                    numPtr2 += num4;
                    numPtr3 += num5;
                    numPtr += num3;
                }
            }
            image.Dispose();
            if (image3 != sourceData)
            {
                image3.Dispose();
            }
        }

        public IFilter Filter1
        {
            get
            {
                return this.filter1;
            }
            set
            {
                if (!(value is IFilterInformation))
                {
                    throw new ArgumentException("The specified filter does not implement IFilterInformation interface.");
                }
                IFilterInformation information = (IFilterInformation) value;
                if (!information.FormatTranslations.ContainsKey(PixelFormat.Format24bppRgb))
                {
                    throw new UnsupportedImageFormatException("The specified filter does not support 24 bpp color images.");
                }
                if ((((PixelFormat) information.FormatTranslations[PixelFormat.Format24bppRgb]) != PixelFormat.Format24bppRgb) && (((PixelFormat) information.FormatTranslations[PixelFormat.Format24bppRgb]) != PixelFormat.Format8bppIndexed))
                {
                    throw new UnsupportedImageFormatException("The specified filter does not produce image of supported format.");
                }
                this.filter1 = value;
            }
        }

        public IFilter Filter2
        {
            get
            {
                return this.filter2;
            }
            set
            {
                if (!(value is IFilterInformation))
                {
                    throw new ArgumentException("The specified filter does not implement IFilterInformation interface.");
                }
                IFilterInformation information = (IFilterInformation) value;
                if (!information.FormatTranslations.ContainsKey(PixelFormat.Format24bppRgb))
                {
                    throw new UnsupportedImageFormatException("The specified filter does not support 24 bpp color images.");
                }
                if ((((PixelFormat) information.FormatTranslations[PixelFormat.Format24bppRgb]) != PixelFormat.Format24bppRgb) && (((PixelFormat) information.FormatTranslations[PixelFormat.Format24bppRgb]) != PixelFormat.Format8bppIndexed))
                {
                    throw new UnsupportedImageFormatException("The specified filter does not produce image of supported format.");
                }
                this.filter2 = value;
            }
        }

        public double FilterLevel
        {
            get
            {
                return this.filterLevel;
            }
            set
            {
                this.filterLevel = Math.Max(0.0, Math.Min(1.0, value));
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public double PreserveLevel
        {
            get
            {
                return this.preserveLevel;
            }
            set
            {
                this.preserveLevel = Math.Max(0.0, Math.Min(1.0, value));
            }
        }

        public float[,] Texture
        {
            get
            {
                return this.texture;
            }
            set
            {
                this.texture = value;
            }
        }

        public ITextureGenerator TextureGenerator
        {
            get
            {
                return this.textureGenerator;
            }
            set
            {
                this.textureGenerator = value;
            }
        }
    }
}

