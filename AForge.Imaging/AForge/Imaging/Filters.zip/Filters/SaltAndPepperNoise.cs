﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class SaltAndPepperNoise : BaseInPlacePartialFilter
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;
        private double noiseAmount;
        private Random rand;

        public SaltAndPepperNoise()
        {
            this.noiseAmount = 10.0;
            this.rand = new Random();
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
            this.formatTranslations[PixelFormat.Format32bppRgb] = PixelFormat.Format32bppRgb;
            this.formatTranslations[PixelFormat.Format32bppArgb] = PixelFormat.Format32bppArgb;
        }

        public SaltAndPepperNoise(double noiseAmount) : this()
        {
            this.noiseAmount = noiseAmount;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage image, Rectangle rect)
        {
            int left = rect.Left;
            int top = rect.Top;
            int width = rect.Width;
            int height = rect.Height;
            int stride = image.Stride;
            int num6 = (int) (((width * height) * this.noiseAmount) / 100.0);
            byte[] buffer2 = new byte[2];
            buffer2[1] = 0xff;
            byte[] buffer = buffer2;
            byte* numPtr = (byte*) image.ImageData.ToPointer();
            if (image.PixelFormat == PixelFormat.Format8bppIndexed)
            {
                for (int i = 0; i < num6; i++)
                {
                    int num8 = left + this.rand.Next(width);
                    int num9 = top + this.rand.Next(height);
                    numPtr[(num9 * stride) + num8] = buffer[this.rand.Next(2)];
                }
            }
            else
            {
                int num10 = (image.PixelFormat == PixelFormat.Format24bppRgb) ? 3 : 4;
                for (int j = 0; j < num6; j++)
                {
                    int num12 = left + this.rand.Next(width);
                    int num13 = top + this.rand.Next(height);
                    int num14 = this.rand.Next(3);
                    numPtr[((num13 * stride) + (num12 * num10)) + num14] = buffer[this.rand.Next(2)];
                }
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public double NoiseAmount
        {
            get
            {
                return this.noiseAmount;
            }
            set
            {
                this.noiseAmount = Math.Max(0.0, Math.Min(100.0, value));
            }
        }
    }
}

