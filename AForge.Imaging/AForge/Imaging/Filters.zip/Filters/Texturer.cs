﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using AForge.Imaging.Textures;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class Texturer : BaseInPlacePartialFilter
    {
        private double filterLevel;
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;
        private double preserveLevel;
        private float[,] texture;
        private ITextureGenerator textureGenerator;

        private Texturer()
        {
            this.filterLevel = 0.5;
            this.preserveLevel = 0.5;
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
        }

        public Texturer(float[,] texture) : this()
        {
            this.texture = texture;
        }

        public Texturer(ITextureGenerator generator) : this()
        {
            this.textureGenerator = generator;
        }

        public Texturer(float[,] texture, double filterLevel, double preserveLevel) : this()
        {
            this.texture = texture;
            this.filterLevel = filterLevel;
            this.preserveLevel = preserveLevel;
        }

        public Texturer(ITextureGenerator generator, double filterLevel, double preserveLevel) : this()
        {
            this.textureGenerator = generator;
            this.filterLevel = filterLevel;
            this.preserveLevel = preserveLevel;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage image, Rectangle rect)
        {
            int num = Image.GetPixelFormatSize(image.PixelFormat) / 8;
            int width = rect.Width;
            int height = rect.Height;
            int num4 = width;
            int num5 = height;
            if (this.textureGenerator != null)
            {
                this.texture = this.textureGenerator.Generate(width, height);
            }
            else
            {
                num4 = Math.Min(width, this.texture.GetLength(1));
                num5 = Math.Min(height, this.texture.GetLength(0));
            }
            int num6 = image.Stride - (num4 * num);
            byte* numPtr = (byte*) (image.ImageData.ToPointer() + ((rect.Top * image.Stride) + (rect.Left * num)));
            for (int i = 0; i < num5; i++)
            {
                for (int j = 0; j < num4; j++)
                {
                    double num9 = this.texture[i, j];
                    int num10 = 0;
                    while (num10 < num)
                    {
                        numPtr[0] = (byte) Math.Min((double) 255.0, (double) ((this.preserveLevel * numPtr[0]) + ((this.filterLevel * numPtr[0]) * num9)));
                        num10++;
                        numPtr++;
                    }
                }
                numPtr += num6;
            }
        }

        public double FilterLevel
        {
            get
            {
                return this.filterLevel;
            }
            set
            {
                this.filterLevel = Math.Max(0.0, Math.Min(1.0, value));
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public double PreserveLevel
        {
            get
            {
                return this.preserveLevel;
            }
            set
            {
                this.preserveLevel = Math.Max(0.0, Math.Min(1.0, value));
            }
        }

        public float[,] Texture
        {
            get
            {
                return this.texture;
            }
            set
            {
                this.texture = value;
            }
        }

        public ITextureGenerator TextureGenerator
        {
            get
            {
                return this.textureGenerator;
            }
            set
            {
                this.textureGenerator = value;
            }
        }
    }
}

