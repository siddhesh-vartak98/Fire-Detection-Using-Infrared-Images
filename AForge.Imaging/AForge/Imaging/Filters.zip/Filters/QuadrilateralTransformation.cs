﻿namespace AForge.Imaging.Filters
{
    using AForge;
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class QuadrilateralTransformation : BaseTransformationFilter
    {
        private bool automaticSizeCalculaton;
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;
        protected int newHeight;
        protected int newWidth;
        private List<IntPoint> sourceQuadrilateral;
        private bool useInterpolation;

        public QuadrilateralTransformation()
        {
            this.automaticSizeCalculaton = true;
            this.useInterpolation = true;
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
            this.formatTranslations[PixelFormat.Format32bppRgb] = PixelFormat.Format32bppRgb;
            this.formatTranslations[PixelFormat.Format32bppArgb] = PixelFormat.Format32bppArgb;
            this.formatTranslations[PixelFormat.Format32bppPArgb] = PixelFormat.Format32bppPArgb;
        }

        public QuadrilateralTransformation(List<IntPoint> sourceQuadrilateral) : this()
        {
            this.automaticSizeCalculaton = true;
            this.sourceQuadrilateral = sourceQuadrilateral;
            this.CalculateDestinationSize();
        }

        public QuadrilateralTransformation(List<IntPoint> sourceQuadrilateral, int newWidth, int newHeight) : this()
        {
            this.automaticSizeCalculaton = false;
            this.sourceQuadrilateral = sourceQuadrilateral;
            this.newWidth = newWidth;
            this.newHeight = newHeight;
        }

        private void CalculateDestinationSize()
        {
            if (this.sourceQuadrilateral == null)
            {
                throw new NullReferenceException("Source quadrilateral was not set.");
            }
            IntPoint point = this.sourceQuadrilateral[0];
            IntPoint point2 = this.sourceQuadrilateral[2];
            this.newWidth = (int) Math.Max(point.DistanceTo(this.sourceQuadrilateral[1]), point2.DistanceTo(this.sourceQuadrilateral[3]));
            IntPoint point3 = this.sourceQuadrilateral[1];
            IntPoint point4 = this.sourceQuadrilateral[3];
            this.newHeight = (int) Math.Max(point3.DistanceTo(this.sourceQuadrilateral[2]), point4.DistanceTo(this.sourceQuadrilateral[0]));
        }

        protected override Size CalculateNewImageSize(UnmanagedImage sourceData)
        {
            if (this.sourceQuadrilateral == null)
            {
                throw new NullReferenceException("Source quadrilateral was not set.");
            }
            return new Size(this.newWidth, this.newHeight);
        }

        protected override unsafe void ProcessFilter(UnmanagedImage sourceData, UnmanagedImage destinationData)
        {
            int width = sourceData.Width;
            int height = sourceData.Height;
            int num3 = destinationData.Width;
            int num4 = destinationData.Height;
            int num5 = Image.GetPixelFormatSize(sourceData.PixelFormat) / 8;
            int stride = sourceData.Stride;
            int num8 = destinationData.Stride - (num3 * num5);
            double[,] numArray = QuadTransformationCalcs.MapQuadToQuad(new List<IntPoint> { new IntPoint(0, 0), new IntPoint(num3 - 1, 0), new IntPoint(num3 - 1, num4 - 1), new IntPoint(0, num4 - 1) }, this.sourceQuadrilateral);
            byte* numPtr = (byte*) destinationData.ImageData.ToPointer();
            byte* numPtr2 = (byte*) sourceData.ImageData.ToPointer();
            if (!this.useInterpolation)
            {
                for (int i = 0; i < num4; i++)
                {
                    for (int j = 0; j < num3; j++)
                    {
                        double num11 = ((numArray[2, 0] * j) + (numArray[2, 1] * i)) + numArray[2, 2];
                        double num12 = (((numArray[0, 0] * j) + (numArray[0, 1] * i)) + numArray[0, 2]) / num11;
                        double num13 = (((numArray[1, 0] * j) + (numArray[1, 1] * i)) + numArray[1, 2]) / num11;
                        if (((num12 >= 0.0) && (num13 >= 0.0)) && ((num12 < width) && (num13 < height)))
                        {
                            byte* numPtr3 = (numPtr2 + (((int) num13) * stride)) + (((int) num12) * num5);
                            int num14 = 0;
                            while (num14 < num5)
                            {
                                numPtr[0] = numPtr3[0];
                                num14++;
                                numPtr++;
                                numPtr3++;
                            }
                        }
                        else
                        {
                            numPtr += num5;
                        }
                    }
                    numPtr += num8;
                }
            }
            else
            {
                int num15 = width - 1;
                int num16 = height - 1;
                for (int k = 0; k < num4; k++)
                {
                    for (int m = 0; m < num3; m++)
                    {
                        double num27 = ((numArray[2, 0] * m) + (numArray[2, 1] * k)) + numArray[2, 2];
                        double num28 = (((numArray[0, 0] * m) + (numArray[0, 1] * k)) + numArray[0, 2]) / num27;
                        double num29 = (((numArray[1, 0] * m) + (numArray[1, 1] * k)) + numArray[1, 2]) / num27;
                        if (((num28 >= 0.0) && (num29 >= 0.0)) && ((num28 < width) && (num29 < height)))
                        {
                            byte* numPtr5;
                            byte* numPtr7;
                            int num21 = (int) num28;
                            int num23 = (num21 == num15) ? num21 : (num21 + 1);
                            double num17 = num28 - num21;
                            double num19 = 1.0 - num17;
                            int num22 = (int) num29;
                            int num24 = (num22 == num16) ? num22 : (num22 + 1);
                            double num18 = num29 - num22;
                            double num20 = 1.0 - num18;
                            byte* numPtr4 = numPtr5 = numPtr2 + (num22 * stride);
                            numPtr4 += num21 * num5;
                            numPtr5 += num23 * num5;
                            byte* numPtr6 = numPtr7 = numPtr2 + (num24 * stride);
                            numPtr6 += num21 * num5;
                            numPtr7 += num23 * num5;
                            int num30 = 0;
                            while (num30 < num5)
                            {
                                numPtr[0] = (byte) ((num20 * ((num19 * numPtr4[0]) + (num17 * numPtr5[0]))) + (num18 * ((num19 * numPtr6[0]) + (num17 * numPtr7[0]))));
                                num30++;
                                numPtr++;
                                numPtr4++;
                                numPtr5++;
                                numPtr6++;
                                numPtr7++;
                            }
                        }
                        else
                        {
                            numPtr += num5;
                        }
                    }
                    numPtr += num8;
                }
            }
        }

        public bool AutomaticSizeCalculaton
        {
            get
            {
                return this.automaticSizeCalculaton;
            }
            set
            {
                this.automaticSizeCalculaton = value;
                if (value)
                {
                    this.CalculateDestinationSize();
                }
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public int NewHeight
        {
            get
            {
                return this.newHeight;
            }
            set
            {
                if (!this.automaticSizeCalculaton)
                {
                    this.newHeight = Math.Max(1, value);
                }
            }
        }

        public int NewWidth
        {
            get
            {
                return this.newWidth;
            }
            set
            {
                if (!this.automaticSizeCalculaton)
                {
                    this.newWidth = Math.Max(1, value);
                }
            }
        }

        public List<IntPoint> SourceQuadrilateral
        {
            get
            {
                return this.sourceQuadrilateral;
            }
            set
            {
                this.sourceQuadrilateral = value;
                if (this.automaticSizeCalculaton)
                {
                    this.CalculateDestinationSize();
                }
            }
        }

        public bool UseInterpolation
        {
            get
            {
                return this.useInterpolation;
            }
            set
            {
                this.useInterpolation = value;
            }
        }
    }
}

