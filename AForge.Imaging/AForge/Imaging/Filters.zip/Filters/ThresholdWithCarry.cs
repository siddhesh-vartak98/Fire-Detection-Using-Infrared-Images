﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class ThresholdWithCarry : BaseInPlacePartialFilter
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations;
        private byte threshold;

        public ThresholdWithCarry()
        {
            this.threshold = 0x80;
            this.formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
        }

        public ThresholdWithCarry(byte threshold) : this()
        {
            this.threshold = threshold;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage image, Rectangle rect)
        {
            int left = rect.Left;
            int top = rect.Top;
            int num3 = left + rect.Width;
            int num4 = top + rect.Height;
            int num5 = image.Stride - rect.Width;
            short num6 = 0;
            byte* numPtr = (byte*) (image.ImageData.ToPointer() + ((top * image.Stride) + left));
            for (int i = top; i < num4; i++)
            {
                num6 = 0;
                int num8 = left;
                while (num8 < num3)
                {
                    num6 = (short) (num6 + numPtr[0]);
                    if (num6 >= this.threshold)
                    {
                        numPtr[0] = 0xff;
                        num6 = (short) (num6 - 0xff);
                    }
                    else
                    {
                        numPtr[0] = 0;
                    }
                    num8++;
                    numPtr++;
                }
                numPtr += num5;
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public byte ThresholdValue
        {
            get
            {
                return this.threshold;
            }
            set
            {
                this.threshold = value;
            }
        }
    }
}

