﻿namespace AForge.Imaging.Filters
{
    using AForge.Imaging;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;

    public class WaterWave : BaseFilter
    {
        private Dictionary<PixelFormat, PixelFormat> formatTranslations = new Dictionary<PixelFormat, PixelFormat>();
        private int xWavesAmplitude = 10;
        private int xWavesCount = 5;
        private int yWavesAmplitude = 10;
        private int yWavesCount = 5;

        public WaterWave()
        {
            this.formatTranslations[PixelFormat.Format8bppIndexed] = PixelFormat.Format8bppIndexed;
            this.formatTranslations[PixelFormat.Format24bppRgb] = PixelFormat.Format24bppRgb;
            this.formatTranslations[PixelFormat.Format32bppRgb] = PixelFormat.Format32bppRgb;
            this.formatTranslations[PixelFormat.Format32bppArgb] = PixelFormat.Format32bppArgb;
        }

        protected override unsafe void ProcessFilter(UnmanagedImage source, UnmanagedImage destination)
        {
            int num = Image.GetPixelFormatSize(source.PixelFormat) / 8;
            int width = source.Width;
            int height = source.Height;
            int stride = source.Stride;
            int num6 = destination.Stride - (width * num);
            int num17 = height - 1;
            int num18 = width - 1;
            byte* numPtr = (byte*) source.ImageData.ToPointer();
            byte* numPtr2 = (byte*) destination.ImageData.ToPointer();
            double num19 = (6.2831853071795862 * this.xWavesCount) / ((double) width);
            double num20 = (6.2831853071795862 * this.yWavesCount) / ((double) height);
            for (int i = 0; i < height; i++)
            {
                double num22 = Math.Sin(num20 * i) * this.yWavesAmplitude;
                for (int j = 0; j < width; j++)
                {
                    double num7 = j + num22;
                    double num8 = i + (Math.Cos(num19 * j) * this.xWavesAmplitude);
                    if (((num7 >= 0.0) && (num8 >= 0.0)) && ((num7 < width) && (num8 < height)))
                    {
                        int num14 = (int) num8;
                        int num16 = (num14 == num17) ? num14 : (num14 + 1);
                        double num10 = num8 - num14;
                        double num12 = 1.0 - num10;
                        int num13 = (int) num7;
                        int num15 = (num13 == num18) ? num13 : (num13 + 1);
                        double num9 = num7 - num13;
                        double num11 = 1.0 - num9;
                        byte* numPtr3 = (numPtr + (num14 * stride)) + (num13 * num);
                        byte* numPtr4 = (numPtr + (num14 * stride)) + (num15 * num);
                        byte* numPtr5 = (numPtr + (num16 * stride)) + (num13 * num);
                        byte* numPtr6 = (numPtr + (num16 * stride)) + (num15 * num);
                        int num24 = 0;
                        while (num24 < num)
                        {
                            numPtr2[0] = (byte) ((num12 * ((num11 * numPtr3[0]) + (num9 * numPtr4[0]))) + (num10 * ((num11 * numPtr5[0]) + (num9 * numPtr6[0]))));
                            num24++;
                            numPtr2++;
                            numPtr3++;
                            numPtr4++;
                            numPtr5++;
                            numPtr6++;
                        }
                    }
                    else
                    {
                        int num25 = 0;
                        while (num25 < num)
                        {
                            numPtr2[0] = 0;
                            num25++;
                            numPtr2++;
                        }
                    }
                }
                numPtr2 += num6;
            }
        }

        public override Dictionary<PixelFormat, PixelFormat> FormatTranslations
        {
            get
            {
                return this.formatTranslations;
            }
        }

        public int HorizontalWavesAmplitude
        {
            get
            {
                return this.xWavesAmplitude;
            }
            set
            {
                this.xWavesAmplitude = Math.Max(0, Math.Min(0x2710, value));
            }
        }

        public int HorizontalWavesCount
        {
            get
            {
                return this.xWavesCount;
            }
            set
            {
                this.xWavesCount = Math.Max(1, Math.Min(0x2710, value));
            }
        }

        public int VerticalWavesAmplitude
        {
            get
            {
                return this.yWavesAmplitude;
            }
            set
            {
                this.yWavesAmplitude = Math.Max(0, Math.Min(0x2710, value));
            }
        }

        public int VerticalWavesCount
        {
            get
            {
                return this.yWavesCount;
            }
            set
            {
                this.yWavesCount = Math.Max(1, Math.Min(0x2710, value));
            }
        }
    }
}

